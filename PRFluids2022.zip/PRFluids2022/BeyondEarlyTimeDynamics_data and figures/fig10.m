%%
c        = parula(6); % Set color vector
col1=c(1,:);col2=c(2,:);col3='r';
%% dimple evolution

figure(1)
    tt=tiledlayout(2,1);
    tt.TileSpacing = 'none';
    ax = nexttile;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('X_inf_1000_Bo_0.mat') % H0 = 100;
    Vg = Xc^2/H_inf^4;
    A  = Xc^2/H_inf;
    tcoe= Vg^(-1/3)*A^(-5/3);
length_t  = length(t);              %% number of recorded profiles
Deltax    = xf(2:N+1)-xf(1:N);      %% xf are grid points
Profile   = y';                     %% profiles
epsi      = 1;                      %width of delta function

for i = 2:length_t
    inds=find(x>1.0*Xc);
    [hmin,imin]=min(y(i,inds));
    hmine(i,1)=hmin;
    imin=imin+min(inds)-1;
    xmine(i,1)=x(imin);
    if imin == N
        imin =N-1;
    end
    inds=find(x>x(imin));
    [hmax,imax]=max(y(i,inds));
    hmaxe(i,1)=hmax;
    imax=imax+min(inds)-1;
    xmaxe(i,1)=x(imax);
    if xmine(i-1,1)>0.95e5
           xmine(i,1)=xmine(i-1,1);
    end
    if xmaxe(i-1,1)>0.95e5
           xmaxe(i,1)=xmaxe(i-1,1);
    end
        iplot = i;
        Hx    = (Profile(3:N,iplot)-Profile(1:N-2,iplot))./(Deltax(1:N-2)/2+Deltax(2:N-1)+Deltax(3:N)/2);
        Hxx   = 2*(Profile(3:N,iplot)-Profile(2:N-1,iplot))./Deltax(2:N-1)./(Deltax(3:N)+Deltax(2:N-1)) - 2*(Profile(2:N-1,iplot)-Profile(1:N-2,iplot))./Deltax(2:N-1)./(Deltax(1:N-2)+Deltax(2:N-1));
        Hxxx  = (Hxx(3:N-2)-Hxx(1:N-4))./(Deltax(2:N-3)/2+Deltax(3:N-2)+Deltax(4:N-1)/2);
        Flux  = Hx.*(3./Profile(2:N-1,iplot)+Bo.*Profile(2:N-1,iplot).^3);
        Pre_ext   = 1/2*(1 + tanh((Xc-x)/epsi))-Xc/2/epsi*(sech((x-Xc)/epsi)).^2; % external pressure
        pre   = -1/2/epsi^2*(sech((xf-Xc)/epsi)).^2.*(epsi + 2*Xc*tanh((Xc-xf)/epsi)); % dpext/dx
        FluxF = Profile(3:N-2,iplot).^3.*(pre(3:N-2)+pre(4:N-1))/2 + Hx(2:N-3).*(3./Profile(3:N-2,iplot)+Bo.*Profile(3:N-2,iplot).^3) - Profile(3:N-2,iplot).^3.*Hxxx;
        inds1=find(x>x(imin));
        inds=inds(1:end-2);
        FluxPart = FluxF(inds-2);
        indsFlux = find(FluxPart<0);
        if isempty(indsFlux) < 0.5
            iminF=min(inds1)+min(indsFlux);
            xstag(i,1)=x(iminF);  
        end
        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        loglog(t*tcoe,(xmine-Xc)/Xc,'r-','LineWidth',1)
        hold on
        loglog(t*tcoe,(xmaxe-Xc)/Xc,'b-','LineWidth',1)
        hold on
        loglog(t(1:length(xstag))*tcoe,(xstag-Xc)/Xc,'g-','LineWidth',1)
        hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
load('X_inf_1000.mat') % Bo = 1e-6; H0 = 100;
    Vg = Xc^2/H_inf^4;
    A  = Xc^2/H_inf;
    tcoe= Vg^(-1/3)*A^(-5/3);
length_t  = length(t);              %% number of recorded profiles
Deltax    = xf(2:N+1)-xf(1:N);      %% xf are grid points
Profile   = y';                     %% profiles
epsi      = 1;                      %width of delta function

for i = 2:length_t
    inds=find(x>1.0*Xc);
    [hmin,imin]=min(y(i,inds));
    hmine(i,1)=hmin;
    imin=imin+min(inds)-1;
    xmine(i,1)=x(imin);
    if xmine(i-1,1)>0.9e5
           xmine(i,1)=xmine(i-1,1);
    end
        
    if imin == N
        imin =N-1;
    end
    inds=find(x>x(imin));
    [hmax,imax]=max(y(i,inds));
    hmaxe(i,1)=hmax;
    imax=imax+min(inds)-1;
    xmaxe(i,1)=x(imax);
    if xmaxe(i-1,1)>0.95e5
           xmaxe(i,1)=xmaxe(i-1,1);
    end
end
        loglog(t*tcoe,(xmine-Xc)/Xc,'r--','LineWidth',1)
        hold on
        loglog(t*tcoe,(xmaxe-Xc)/Xc,'b--','LineWidth',1)
        hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        xval = logspace(-5,0,40);
        loglog(xval*tcoe,2.3*(H_inf^3*xval).^0.25/Xc,'k--','LineWidth',0.8);    hold on
        loglog(xval*tcoe,4.592*(H_inf^3*xval).^0.25/Xc,'k--','LineWidth',0.8);    hold on
        loglog(xval*tcoe,5.81/Xc*H_inf*(Xc^4/H_inf*xval).^0.25/Xc,'k--','LineWidth',0.8); hold on
        xval = logspace(1,6,10);
        loglog(xval*tcoe,2.85*(xval*tcoe).^0.25,'k:','LineWidth',0.8); hold on
        

        xval = logspace(7,8.8,10);
        loglog(xval*tcoe,0.1*(xval).^0.4/Xc,'k-','LineWidth',0.8);hold on
        loglog(xval*tcoe,0*xval+0.1*(xval(1)).^0.4/Xc,'k-','LineWidth',0.8);hold on
        loglog([xval(end)*tcoe,xval(end)*tcoe],[0.1*(xval(1)).^0.4,0.1*(xval(end)).^0.4]/Xc,'k-','LineWidth',0.8);hold on


        set(gca, 'XLim', [1e-5*tcoe, 1e11*tcoe]) 
        set(gca, 'YLim', [2e-2, 2e3])
        ylabel('Dimple','interpreter','latex')
        text(1e3,8e1,'$X_\mathrm{max}-1$','FontSize',11,'interpreter','latex','Color','b');
        text(1e3,1e-1,'$X_\mathrm{min}-1$','FontSize',11,'interpreter','latex','Color','r');
        text(1e3,1e-1,'$X_\mathrm{s.p.}-1$','FontSize',11,'interpreter','latex','Color','g');
        axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);
        set(ax,'XTicklabels',[]);
        
              
ax = nexttile;
        loglog(t*tcoe,hmine/H_inf,'r--','LineWidth',1)
        hold on
        loglog(t(1:end-400)*tcoe,(hmaxe(1:end-400)-H_inf)/H_inf,'b--','LineWidth',1)
        hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('X_inf_1000_Bo_0.mat') % H0 = 100;

length_t  = length(t);              %% number of recorded profiles
Deltax    = xf(2:N+1)-xf(1:N);      %% xf are grid points
Profile   = y';                     %% profiles
epsi      = 1;                      %width of delta function

for i = 2:length_t
    inds=find(x>1.0*Xc);
    [hmin,imin]=min(y(i,inds));
    hmine(i,1)=hmin;
    imin=imin+min(inds)-1;
    xmine(i,1)=x(imin);
    if imin == N
        imin =N-1;
    end
    inds=find(x>x(imin));
    [hmax,imax]=max(y(i,inds));
    hmaxe(i,1)=hmax;
    imax=imax+min(inds)-1;
    xmaxe(i,1)=x(imax);
    if xmine(i-1,1)>0.95e5
           xmine(i,1)=xmine(i-1,1);
    end
    if xmaxe(i-1,1)>0.95e5
           xmaxe(i,1)=xmaxe(i-1,1);
    end
end
        loglog(t*tcoe,hmine/H_inf,'r-','LineWidth',1)
        hold on
        loglog(t*tcoe,(hmaxe-H_inf)/H_inf,'b-','LineWidth',1)
        hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        xval = logspace(-5,0,10);
        loglog(xval*tcoe,0.00943019*H_inf*(Xc^4/H_inf*xval).^0.25/H_inf,'k--','LineWidth',0.8)
        loglog(xval*tcoe,(H_inf-0.305/pi*Xc*(H_inf^3*xval).^0.25)/H_inf,'k--','LineWidth',0.8)
        hold on

        xval = logspace(1,6,10);
        loglog(xval*tcoe,0.24*H_inf/H_inf+0*xval,'k:','LineWidth',0.8)
        
        xval = logspace(7,8.8,10);
        text(0.5*xval(1)*tcoe,0.5*(xval(1)).^0.4,'$2$','FontSize',11,'interpreter','latex','color','k');
        text(0.5*xval(1)*tcoe,0.5*(xval(end)).^0.4,'$5$','FontSize',11,'interpreter','latex','color','k');
        loglog(xval*tcoe,0.04*(xval).^0.2/H_inf,'k-','LineWidth',0.8);hold on
        loglog(xval*tcoe,0*xval+0.04*(xval(1)).^0.2/H_inf,'k-','LineWidth',0.8);hold on
        loglog([xval(end),xval(end)]*tcoe,[0.04*(xval(1)).^0.2,0.04*(xval(end)).^0.2]/H_inf,'k-','LineWidth',0.8);hold on
        text(0.1*xval(1)*tcoe,0.5*(xval(1)).^0.4,'$1$','FontSize',11,'interpreter','latex','color','k');
        text(0.1*xval(1)*tcoe,0.5*(xval(end)).^0.4,'$5$','FontSize',11,'interpreter','latex','color','k');
%         
%         xval = logspace(9.1,10.9,10);
%         loglog(xval*tcoe,0.01*(xval).^(4/15),'k-','LineWidth',0.8);hold on
%         loglog(xval*tcoe,0*xval+0.01*(xval(1)).^(4/15),'k-','LineWidth',0.8);hold on
%         loglog([xval(end)*tcoe,xval(end)*tcoe],[0.01*(xval(1)).^(4/15),0.01*(xval(end)).^(4/15)],'k-','LineWidth',0.8);hold on
%         text(0.5*xval(1)*tcoe,0.1*(xval(1)).^0.2,'$4$','FontSize',11,'interpreter','latex','color','k');
%         text(0.5*xval(1)*tcoe,0.1*(xval(end)).^0.2,'$15$','FontSize',11,'interpreter','latex','color','k');
        
%         xval = logspace(5,8,10);
%         loglog(xval,0.49/2*(xval).^0.4*Vg^(3/10),'k-','LineWidth',0.8);hold on
%         loglog(xval,0.7*(xval).^0.2*Vg^(2/5),'k-','LineWidth',0.8);hold on

        xval = logspace(8,10,10);
        loglog(xval/100,0.03*(xval).^0.4,'k-','LineWidth',0.8);hold on
        loglog(xval/100,0*xval+0.03*(xval(1)).^0.4,'k-','LineWidth',0.8);hold on
        loglog([xval(end),xval(end)]/100,[0.03*(xval(1)).^0.4,0.03*(xval(end)).^0.4],'k-','LineWidth',0.8);hold on
%         text(0.5*xval(1),0.5*(xval(1)).^0.4,'$2$','FontSize',11,'interpreter','latex','color','k');
%         text(0.5*xval(1),0.5*(xval(end)).^0.4,'$1$','FontSize',11,'interpreter','latex','color','k');

        set(gca, 'XLim', [1e-5*tcoe, 1e11*tcoe]) 
        set(gca, 'YLim', [2e-3, 1e1])
        ylabel('Bump','interpreter','latex')

        xlabel('$T$','interpreter','latex')
        text(1e3,0.02,'$H_\mathrm{min}$','FontSize',11,'interpreter','latex','Color','r');
        text(1e3,0.5,'$H_\mathrm{max}-1$','FontSize',11,'interpreter','latex','Color','b');
        axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);
        