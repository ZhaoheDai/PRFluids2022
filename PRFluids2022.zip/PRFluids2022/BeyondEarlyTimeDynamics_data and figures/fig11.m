%% H(0,T)

load('X_inf_1000_Bo_0.mat') %in the folder of LateTimeEvolution
Vg = Xc^2/H_inf^4;
A = Xc^2/H_inf;
t = t*Vg^(-1/3)*A^(-5/3);
semilogy(3*pi*pi/4*A^(1/3)*Vg^(2/3)*t,y(:,1)/H_inf,'k','Linewidth',1); hold on
xval=linspace(0,300,100);
plot(3*pi*pi/4*A^(1/3)*Vg^(2/3)*xval,exp(-3*pi*pi/4*A^(1/3)*Vg^(2/3)*xval),'k--','Linewidth',0.9); hold on
xval=linspace(0,10,100);
plot(xval,0*xval+(Vg/A)^(1/3),'k:','Linewidth',0.9); hold off

axis([0 10 0.001 2])

xlabel('$|\sigma|T$','interpreter','latex','fontsize',12);
ylabel('$H(0,T)$','interpreter','latex','fontsize',12);
hold off
axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
  

%% rescaled profiles
% load('X_inf_1000.mat')
load('X_inf_1000_Bo_0.mat')
% load('X_inf_1000_Bo_0_H0_500.mat')
% load('X_inf_10000_Bo_0_H0_100.mat')

Vg = Xc^2/H_inf^4;
A = Xc^2/H_inf;
t = t*Vg^(-1/3)*A^(-5/3);


maxt=max(t);
logmaxt=floor(log10(maxt));

discrete = 6;                % Plot 10 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = xf(2:N+1)-xf(1:N);      %% xf are grid points

tgoal=logspace(logmaxt-discrete+1-7,logmaxt-5,discrete); % the target values of t that we want to be logarithmically spaced (for now)
% tgoal=logspace(logmaxt-discrete+1-1,logmaxt-1,discrete); % the target values of t that we want to be logarithmically spaced (for now)

for j = 1:discrete
    tgoalNow=tgoal(j);
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);

    % Want to locate the minimum thickness in the positive region
    inds=find(x>Xc);
    [hmin,imin]=min(y(iplot,inds));
    imin=imin+min(inds)-1;
    xmin=x(imin);
        vol=0;
        for jj = imin:N
            vol=vol+(100-y(iplot,jj))*dxf(jj+2);
        end
        vol
        
    % Want to locate the minimum thickness in the inner region
    inds2=find(x<Xc);
    [hmin2,imin2]=min(y(iplot,inds2));
    imin2=imin2+min(inds2)-1;
    xmin2=x(imin2);
    %find bulge maximum
    inds=find(x>x(imin));
    [hmax,imax]=max(y(iplot,inds));
    imax=imax+min(inds)-1;
    xmax=x(imax);
    
    figure(1001)
        plot(x/Xc,y(iplot,:)/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on
        plot(xmin/Xc,hmin/H_inf,'bo','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on
        plot(xmax/Xc,hmax/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
    figure(1003)
        plot((x-xmin)/Xc/tplot^0.25,(y(iplot,:))/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on

end
figure(1001)
    xlabel('$X$','interpreter','latex','fontsize',12);
    ylabel('$H$','interpreter','latex','fontsize',12);
    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'log')
    axis([2e-1 1e3 5e-3 2e1])
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    tx = text(2e1,2e0,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.0f'),num2str(log10(tgoal(2)),'%.0f'),num2str(log10(tgoal(3)),'%.0f'),num2str(log10(tgoal(4)),'%.0f'),num2str(log10(tgoal(5)),'%.0f'),num2str(log10(tgoal(6)),'%.0f')},'fontsize',10,'Location','eastoutside');
    set(c,'TickLabelInterpreter','latex');

figure(1003)
    plot(x_sim, y_sim, 'k--','LineWidth',1); hold on
    xlabel('$(X-X_\mathrm{min})/T^{1/4}$','interpreter','latex','fontsize',12);
    ylabel('$H$','interpreter','latex','fontsize',12);
    axis([-0 15 0 1.3])
%     set(gca, 'YScale', 'log')
%     set(gca, 'XScale', 'log')
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    tx = text(1,0.2,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.0f'),num2str(log10(tgoal(2)),'%.0f'),num2str(log10(tgoal(3)),'%.0f'),num2str(log10(tgoal(4)),'%.0f'),num2str(log10(tgoal(5)),'%.0f'),num2str(log10(tgoal(6)),'%.0f')},'fontsize',10,'Location','eastoutside');
    set(c,'TickLabelInterpreter','latex');



