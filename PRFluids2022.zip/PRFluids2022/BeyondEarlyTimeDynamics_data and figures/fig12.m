%% figure 3 rescaled profiles
% load('X_inf_1000.mat')
load('X_inf_1000_Bo_0.mat')
% load('X_inf_1000_Bo_0_H0_500.mat')
% load('X_inf_10000_Bo_0_H0_100.mat')

Vg = Xc^2/H_inf^4;
A = Xc^2/H_inf;
t = t*Vg^(-1/3)*A^(-5/3);
xmint=1*Xc;
maxt=max(t);
logmaxt=floor(log10(maxt));

discrete = 6;                % Plot 10 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = xf(2:N+1)-xf(1:N);      %% xf are grid points

% tgoal=logspace(logmaxt-discrete+1,logmaxt,discrete); % the target values of t that we want to be logarithmically spaced (for now)
tgoal=logspace(5,8,discrete); % the target values of t that we want to be logarithmically spaced (for now)

for j = 1:discrete
    tgoalNow=tgoal(j);
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);

    % Want to locate the minimum thickness in the positive region
%     Hxx   = 2*(Profile(3:N,i)-Profile(2:N-1,i))./Deltax(2:N-1)./(Deltax(3:N)+Deltax(2:N-1)) - 2*(Profile(2:N-1,i)-Profile(1:N-2,i))./Deltax(2:N-1)./(Deltax(1:N-2)+Deltax(2:N-1));
    inds=find(x>Xc);
    [hmin,imin]=min(y(iplot,inds));
    imin=imin+min(inds)-1;
    rechmin(j)=hmin/H_inf/tplot^(1/5)/Vg^(2/5);
%     rechxx(j)=Hxx(imin)/H_inf*Xc^2/Vg*(hmin/H_inf)^3;
    xmin=x(imin);
    recxmin(j)=(xmin-Xc)/Xc/Vg^(3/10)/tplot^(2/5);
        vol=0;
        for jj = imin:N
            vol=vol+(100-y(iplot,jj))*dxf(jj+2);
        end
        vol
        
    % Want to locate the minimum thickness in the inner region
    inds2=find(x<Xc);
    [hmin2,imin2]=min(y(iplot,inds2));
    imin2=imin2+min(inds2)-1;
    xmin2=x(imin2);
    %find bulge maximum
    inds=find(x>x(imin));
    [hmax,imax]=max(y(iplot,inds));
    imax=imax+min(inds)-1;
    xmax=x(imax);
    
    figure(1001)
        indsNeg=find(x<xmin);
        plot(x(indsNeg)/Xc,y(iplot,indsNeg)/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on
        indsPos=find(x>xmin);
        plot(x(indsPos)/Xc,y(iplot,indsPos)/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on
        plot(xmin/Xc,hmin/H_inf,'bo','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on
        plot(xmax/Xc,hmax/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
    figure(1002)
        indsNeg=find(x<xmin);
%         plot(abs((x(indsNeg)-xmin)./(hmin.^2))*H_inf^2/Xc,y(iplot,indsNeg)./hmin-1,'--','LineWidth',1,'Color',c(j,:)); hold on
        plot(abs((x(indsNeg))-xmint)/Xc/tplot^(2/5)/Vg^(3/10),y(iplot,indsNeg)/H_inf/tplot^(1/5)/Vg^(2/5),'-','LineWidth',1,'Color',c(j,:)); hold on
        indsPos=find(x>xmin);
%         plot(abs((x(indsPos)-xmin)./(hmin^2))*H_inf^2/Xc,y(iplot,indsPos)./hmin-1,'LineWidth',1,'Color',c(j,:)); hold on
%         plot((xmax-xmin)/hmin^2*H_inf^2/Xc,y(iplot,imax)/hmin-1,'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
        plot(abs((x(indsPos))-xmint)/Xc/tplot^(2/5)/Vg^(3/10),(y(iplot,indsPos)/H_inf/tplot^(1/5)/Vg^(2/5)),'LineWidth',1,'Color',c(j,:)); hold on
        plot((xmax-xmint)/Xc/tplot^(2/5)/Vg^(3/10),y(iplot,imax)/H_inf/tplot^(1/5)/Vg^(2/5),'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
        plot((xmin-Xc)/Xc/tplot^(2/5)/Vg^(3/10),hmin/H_inf/tplot^(1/5)/Vg^(2/5),'bo','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on
        
end
figure(1001)
    xlabel('$X$','interpreter','latex','fontsize',12);
    ylabel('$H$','interpreter','latex','fontsize',12);
    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'log')
    axis([1e-1 1e3 5e-3 1e2])
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
%     tx = text(2e3,2e0,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.0f'),num2str(log10(tgoal(2)),'%.0f'),num2str(log10(tgoal(3)),'%.0f'),num2str(log10(tgoal(4)),'%.0f'),num2str(log10(tgoal(5)),'%.0f'),num2str(log10(tgoal(6)),'%.0f')},'fontsize',10,'Location','eastoutside');
    set(c,'TickLabelInterpreter','latex');
figure(1002)
%     xvals=linspace(0,0.24,100);
%     plot(xvals,0.5/0.074^3*(xvals-0.24).^2,'k:','LineWidth',0.8); hold on
%     xvals=linspace(0.3,5,100);
%     plot(xvals,0.0743*exp((xvals-0.24)/3/0.24),'r:','LineWidth',0.8); hold on
%     xlabel('$|X-X_\mathrm{min}|/(\mathcal V_\gamma^{3/10} T^{2/5})$','interpreter','latex','fontsize',12);
    xlabel('$(X-1)/(\mathcal V_\gamma^{3/10} T^{2/5})$','interpreter','latex','fontsize',12);
    ylabel('$H/(\mathcal V_\gamma^{2/5} T^{1/5})$','interpreter','latex','fontsize',12);

%     axis([1e1 1e6 1e-4 3e3])
    axis([0.1 10 5e-2 100])

    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'linear')
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
%     tx = text(2e1,5e4,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.1f'),num2str(log10(tgoal(2)),'%.1f'),num2str(log10(tgoal(3)),'%.1f'),num2str(log10(tgoal(4)),'%.1f'),num2str(log10(tgoal(5)),'%.1f'),num2str(log10(tgoal(6)),'%.1f')},'fontsize',10,'Location','eastoutside');
    set(c,'TickLabelInterpreter','latex');
    

