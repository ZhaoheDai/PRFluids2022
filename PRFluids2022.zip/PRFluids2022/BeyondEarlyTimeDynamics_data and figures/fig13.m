%%
load('Summary_ZeroBo.mat')
ceof =1;
c        = parula(13); % Set color vector
for i = 1:length(recA)
    if round(recA(i)) == 100
    if round(recn(i)) == 10
        if recn(i) > ceof*recA(i)*recVg(i)^(-1/2)
            recn(i) = ceof*recA(i)*recVg(i)^(-1/2);
        end
        col = c((round(2*log10(recVg(i))+13)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'o','Linewidth',1,'MarkerSize',5,'MarkerEdgeColor',col);hold on
    end
    
    if round(recn(i)) == 100
        if recn(i) > ceof*recA(i)*recVg(i)^(-1/2)
            recn(i) = ceof*recA(i)*recVg(i)^(-1/2);
        end
        col = c((round(2*log10(recVg(i))+13)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'s','Linewidth',1,'MarkerSize',5,'MarkerEdgeColor',col);hold on
    end
    
    if round(recn(i)) == 1000
        i
                    an=recn(i)
            ac=ceof*recA(i)*recVg(i)^(-1/2)
            av=recVg(i)
        if recn(i) > ceof*recA(i)*recVg(i)^(-1/2)
            recn(i) = ceof*recA(i)*recVg(i)^(-1/2);
        end
        col = c((round(2*log10(recVg(i))+13)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'d','Linewidth',1,'MarkerSize',5,'MarkerEdgeColor',col);hold on
    end
    end
    if round(recA(i)) == 25
        if recn(i) > recA(i)*recVg(i)^(-1/2)
            recn(i) = recA(i)*recVg(i)^(-1/2);
        end

        if round(log10(recVg(i))) < -5.5
        col = c((round(log10(recVg(i))+8)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'p','Linewidth',1,'MarkerSize',5,'MarkerEdgeColor',col);hold on
        end
        if round(log10(recVg(i))) > -5.5
        col = c((round(2*log10(recVg(i))+13)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'p','Linewidth',1,'MarkerSize',5,'MarkerEdgeColor',col);hold on
        end
    end
end

load('Summary_NonzeroBo.mat')
coef = 1;
c        = parula(13); % Set color vector
figure(1)
for i = 1:length(recA)
    if round(recA(i)) == 100
    if round(recn(i)) == 10
        grav  = 10^(-2)/recVg(i);
        if recn(i) > coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2)
            recn(i) = coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2);
        end
        col = c((round(2*log10(recVg(i))+11)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'o','MarkerSize',5,'Linewidth',0.8,'MarkerEdgeColor','k','MarkerFaceColor',col);hold on
    end
    
    if round(recn(i)) == 100
                grav  = 10^(-2)/recVg(i);
        if recn(i) > coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2)
            recn(i) = coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2);
        end
        col = c((round(2*log10(recVg(i))+11)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'s','MarkerSize',5,'Linewidth',0.8,'MarkerEdgeColor','k','MarkerFaceColor',col);hold on
    end
    
    if round(recn(i)) == 1000
                grav  = 10^(-2)/recVg(i);
        if recn(i) > coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2)
            recn(i) = coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2);
        end
        col = c((round(2*log10(recVg(i))+11)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'d','MarkerSize',5,'Linewidth',0.8,'MarkerEdgeColor','k','MarkerFaceColor',col);hold on
    end
    end
    if round(recA(i)) == 25
                        grav  = 10^(-2)/recVg(i);
        if recn(i) > coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2)
            recn(i) = coef*recA(i)*recVg(i)^(-1/2)*(1+grav)^(-1/2);
        end
        if round(log10(recVg(i))) < -5.5
        col = c((round(log10(recVg(i))+8)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'p','MarkerSize',6,'Linewidth',0.8,'MarkerEdgeColor','k','MarkerFaceColor',col);hold on
        end
        if round(log10(recVg(i))) > -5.5
        col = c((round(2*log10(recVg(i))+13)),:);
        loglog(recn(i)^(5/2)*recVg(i)^(-3/4),recT(i),'p','MarkerSize',6,'Linewidth',0.8,'MarkerEdgeColor','k','MarkerFaceColor',col);hold on
        end
    end
end

%% Legend

% xlabel('$\mathcal V_\gamma$','interpreter','latex','fontsize',12);
xlabel('$X_\infty^{5/2} \mathcal V_\gamma^{-3/4}$','interpreter','latex','fontsize',12);
ylabel('$T_{90\%}$','interpreter','latex','fontsize',12);

xval = logspace(-2,12,10);
loglog(xval,xval/50,'k-','LineWidth',0.8);hold on
% 
% tx = text(10,20,'$\mathrm{log}_{10}$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
% tx = text(10,10,'$\mathcal V_\gamma$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)

% c  = colorbar('Ticks',[0,1/6,2/6,3/6,4/6,5/6,1],'TickLabels',{num2str(-7,'%.0f'),num2str(-5,'%.0f'),num2str(-4,'%.0f'),num2str(-3,'%.0f'),num2str(-2,'%.0f'),num2str(-1,'%.0f'),num2str(0,'%.0f')},'fontsize',10,'Location','eastoutside');
% set(c,'TickLabelInterpreter','latex');
    
axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.XLim = [1e-2 1e12];
ax.YLim = [1e-2 1e12];
% tx = text(1e-5,1.7e0,'$1$','FontSize',10,'interpreter','latex'); 
% tx = text(1e-5,4e-1,'$1$','FontSize',10,'interpreter','latex');
tx = text(1e5,1e5,'$T_{90\%}=X_\infty^2 \alpha^{-1/3} \mathcal V_\gamma^{-2/3}$','FontSize',10,'interpreter','latex'); 

