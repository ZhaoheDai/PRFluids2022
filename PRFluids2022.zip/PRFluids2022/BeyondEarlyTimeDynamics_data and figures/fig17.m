%% look into the boundary area (no gravity)
% clear
load('X_inf_1000_Bo_0.mat')
% load('X_inf_1000_Bo_0_H0_50.mat')
% load('X_inf_10000_Bo_0_H0_100.mat')

Vg = Xc^2/H_inf^4;
A = Xc^2/H_inf;
t = t*Vg^(-1/3)*A^(-5/3);
y = y/H_inf;
x = x/Xc;
discrete = 6;                % Plot 10 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = (xf(2:N+1)-xf(1:N))/Xc;      %% xf are grid points
hinfe(:,1)= Profile(end,:); 
length_t = length(t);
hinfdot2 = (hinfe(2:length_t)-hinfe(1:length_t-1))./(t(2:length_t)-t(1:length_t-1)); %%evaluated by the true hinfdot
figure(10000)
semilogy(t(2:end),1e5*abs(hinfdot2),'k-','LineWidth',1); hold on
set(gca, 'XLim', [1e10, 1e11]) 
        xval = logspace(10,11,10);
        loglog(xval,0.5*(xval).^(-1),'r-','LineWidth',0.8);hold on

maxt     = max(t);
logmaxt  = floor(log10(maxt));
tgoal=logspace(logmaxt-0.5,logmaxt,discrete); % the target values of t that we want to be logarithmically spaced (for now)
for j = 1:discrete
    tgoalNow=tgoal(j);
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);  
    inds=find(x>Xc);
    [hmin,imin]=min(y(iplot,inds));
    imin=imin+min(inds)-1;
    xmin=x(imin);
    
    figure(10001)
        
        plot((x-x(end)).^2,y(iplot,:)/y(iplot,end),'-','LineWidth',1,'Color',c(j,:)); hold on
        ihinfdot  = hinfdot2(iplot-1);
        ihinf     = Profile(end,iplot);
        %%%%%%%%%%%%%%%%%% another way to estimate ihinfdot
%         tplotleft=t(iplot-1);
%         [hminleft,iminleft]=min(y(iplot-1,inds));
%         iminleft=iminleft+min(inds)-1;
%         xminleft=x(iminleft);
%         xmindot =(xmin-xminleft)/(tplot-tplotleft);
%         ihinfdot=-xmindot*Xc^2/6/X_inf;
%         ihinf   = H_inf-xmin*Xc^2/6/X_inf;
        %%%%%%%%%%%%%%%%%%
        plot((x(end)-10.^(1:0.1:3)).^2,1*exp(-abs(ihinfdot)*(10.^(1:0.1:3)-x(end)).^2/6/Vg),'k--','LineWidth',0.8,'Color',c(j,:)); hold on

end
figure(10001)
    xlabel('$(X-X_\infty)^2$','interpreter','latex','fontsize',12);
    ylabel('$H/H_\infty$','interpreter','latex','fontsize',12);
    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'linear')
    axis([0 1e6 5e-2 5e2])
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    tx = text(4e4,1e3,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.1f'),num2str(log10(tgoal(2)),'%.1f'),num2str(log10(tgoal(3)),'%.1f'),num2str(log10(tgoal(4)),'%.1f'),num2str(log10(tgoal(5)),'%.1f'),num2str(log10(tgoal(6)),'%.1f')},'fontsize',10,'Location','northoutside');
    set(c,'TickLabelInterpreter','latex');
%% Xmin and Hinf
% load('X_inf_1000.mat')
load('X_inf_1000_Bo_0.mat')
% load('X_inf_1000_Bo_0_H0_500.mat')

Vg = Xc^2/H_inf^4;
A = Xc^2/H_inf;
t = t*Vg^(-1/3)*A^(-5/3);

length_t  = length(t);              %% number of recorded profiles
Deltax    = xf(2:N+1)-xf(1:N);      %% xf are grid points
Profile   = y';                     %% profiles
epsi      = 1;                      %width of delta function
Pre_ext   = 1/2*(1 + tanh((Xc-x)/epsi))-Xc/2/epsi*(sech((x-Xc)/epsi)).^2; % external pressure
for i = 1:length_t
    Hx    = (Profile(3:N,i)-Profile(1:N-2,i))./(Deltax(1:N-2)/2+Deltax(2:N-1)+Deltax(3:N)/2);
    Hxx   = 2*(Profile(3:N,i)-Profile(2:N-1,i))./Deltax(2:N-1)./(Deltax(3:N)+Deltax(2:N-1)) - 2*(Profile(2:N-1,i)-Profile(1:N-2,i))./Deltax(2:N-1)./(Deltax(1:N-2)+Deltax(2:N-1));
    Hxxx  = (Hxx(3:N-2)-Hxx(1:N-4))./(Deltax(2:N-3)/2+Deltax(3:N-2)+Deltax(4:N-1)/2);
    Pressure(1:N-2) = Pre_ext(2:N-1) - Hxx(1:N-2) - Profile(2:N-1,i).^(-3) + Bo*Profile(2:N-1,i);
    FluxF = Hx(2:N-3).*(3./Profile(3:N-2,i)+Bo.*Profile(3:N-2,i).^3) - Profile(3:N-2,i).^3.*Hxxx;
    inds=find(x>1.1*Xc);
        p0(i,1)=Pressure(min(inds));
        [hmin,imin]=min(y(i,inds));
        hmine(i,1)=hmin;
        imin=imin+min(inds)-1;
        xmine(i,1)=x(imin);
        if imin > N-2
            imin = N-2;
        end
        hend(i,1) = y(i,end);
        dhdxx(i,1)=Hxx(imin-1);
        q(i,1)=FluxF(imin-2);
    inds=find(x<Xc);
        [hmin,imin]=min(y(i,inds));
        hmine2(i,1)=hmin;
        imin2=imin+min(inds)-1;
        xmine2(i,1)=x(imin);
        if imin <2
            imin = 3;
        end
        q2(i,1)=FluxF(imin-2);   
end
    
figure(2)
    plot(xmine/Xc,hend/H_inf,'k-','LineWidth',1)
    hold on
    xvals=linspace(0,1e2,100);
    plot(xvals,1-A*xvals/6/1000,'k--','LineWidth',0.8); hold on
    xlabel('$X_\mathrm{min}$','interpreter','latex')
    ylabel('$H_\infty$','interpreter','latex')

%     set(gca, 'YScale', 'log')
%     set(gca, 'XScale', 'log')
    axis([0 70 0.1 1.1])
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
%% look into the boundary area (finite Bond number)
clear
% load('X_inf_1000_Bo_0.mat')
load('X_inf_1000.mat')

Vg = Xc^2/H_inf^4;
A = Xc^2/H_inf;
t = t*Vg^(-1/3)*A^(-5/3);
Bo=Bo*Xc^2;
y = y/H_inf;
x = x/Xc;

length_t = length(t);

discrete = 5;                % Plot 10 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = (xf(2:N+1)-xf(1:N))/Xc;      %% xf are grid points
hinfe(:,1)= Profile(end,:); 
hinfdot2 = (hinfe(2:length_t)-hinfe(1:length_t-1))./(t(2:length_t)-t(1:length_t-1)); %%evaluated by the true hinfdot
maxt     = max(t);
logmaxt  = floor(log10(maxt));
tgoal=logspace(logmaxt-1.7,logmaxt-0.7,discrete); % the target values of t that we want to be logarithmically spaced (for now)
for j = 1:discrete
    tgoalNow=tgoal(j);
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);  
    
    figure(10001)
        plot((x-x(end)).^2,1-(y(iplot,:)/y(iplot,end)),'-','LineWidth',1,'Color',c(j,:)); hold on
        plot((x(end)-10.^(1.5:0.01:3)).^2,(abs(hinfdot2(iplot-1))*(10.^(1.5:0.01:3)-x(end)).^2)/2/(3*Vg+Bo*y(iplot,end)^4),'--','LineWidth',0.8,'Color',c(j,:)); hold on
            
    
end
figure(10001)
    xlabel('$(X-X_\infty)^2$','interpreter','latex','fontsize',12);
    ylabel('$1-H/H_\infty$','interpreter','latex','fontsize',12);
%     set(gca, 'YScale', 'log')
%     set(gca, 'XScale', 'log')
    axis([0 1e6 0 1e0])
    hold off
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    tx = text(2e2,2e5,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    c = colorbar('Ticks',[0,0.25,0.5,0.75,1],'TickLabels',{num2str(log10(tgoal(1)),'%.1f'),num2str(log10(tgoal(2)),'%.1f'),num2str(log10(tgoal(3)),'%.1f'),num2str(log10(tgoal(4)),'%.1f'),num2str(log10(tgoal(5)),'%.1f')},'fontsize',10,'Location','northoutside');
    set(c,'TickLabelInterpreter','latex'); 
