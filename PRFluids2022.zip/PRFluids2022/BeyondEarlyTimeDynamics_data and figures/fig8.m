%note that Vg = Xc^2/H_inf^4; A = Xc^2/H_inf; Tnew = T*Vg^(-1/3)*A^(-5/3)
%using non-zero Bo data 
% Vg = 1e-4 in this case: Vg = Xc^4/1e12
% load('Dynamic_Vg_1e-12_Xinf_1000_Alpha_100.mat')
load('X_inf_1000.mat')
Vg = Xc^2/H_inf^4
A  = Xc^2/H_inf
t  = t*Vg^(-1/3)*A^(-5/3);

% figure(1)
% h_ridge = (y(:,N1)*dxf(N1+3) + y(:,N1+1)*dxf(N1+2))/(dxf(N1+2)+dxf(N1+3)); % because of nonuniform grid spacing
% loglog(t,h_ridge,'r','LineWidth',1.5); hold on



maxt=max(t)
logmaxt=floor(log10(maxt))

discrete = 6;                % Plot 6 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = xf(2:N+1)-xf(1:N);      %% xf are grid points

% tgoal=logspace(logmaxt-2*discrete+2,logmaxt,discrete); % the target values of t that we want to be logarithmically spaced (for now)
tgoal=logspace(4,9,discrete); % the target values of t that we want to be logarithmically spaced (for now)

for j = 1:discrete-1
    tgoalNow=tgoal(j)
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);

    % Want to locate the minimum thickness in the positive region
    inds=find(x>Xc);
    [hmin,imin]=min(y(iplot,inds));
    imin=imin+min(inds)-1;
    xmin=x(imin);
        
    % Want to locate the minimum thickness in the inner region
    inds2=find(x<Xc);
    [hmin2,imin2]=min(y(iplot,inds2));
    imin2=imin2+min(inds2)-1;
    xmin2=x(imin2);
    
    %find bulge maximum
    inds=find(x>x(imin));
    [hmax,imax]=max(y(iplot,inds));
    imax=imax+min(inds)-1;
    xmax=x(imax);
    
    figure(1001)
        plot(x/Xc,y(iplot,:)/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on
        plot(xmin/Xc,hmin/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on
        plot(xmax/Xc,hmax/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
end
figure(1001)
    load('Static_Vg_1e-12_Xinf_1000_Alpha_100.mat')
    plot(sol.x/Xc,sol.y(1,:)/H_inf,'k--','LineWidth',0.8); hold on
    
    xlabel('$X=x/x_c$','interpreter','latex','fontsize',12);
    ylabel('$H=h/h_0$','interpreter','latex','fontsize',12);
    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'log')
    
    axis([1e-1 1e3 2e-3 7e1])
    hold off
    
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
%     tx = text(3e-1,1e1,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    tx = text(3e-1,2e0,'$\mathcal{V}_\gamma=10^{-4}$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)

    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.0f'),num2str(log10(tgoal(2)),'%.0f'),num2str(log10(tgoal(3)),'%.0f'),num2str(log10(tgoal(4)),'%.0f'),num2str(log10(tgoal(5)),'%.0f'),num2str(log10(tgoal(6)),'%.0f')},'fontsize',10,'Location','northoutside');
    set(c,'TickLabelInterpreter','latex');
%%
% note that Vg = Xc^2/H_inf^4; A = Xc^2/H_inf; Tnew = T*Vg^(-1/3)*A^(-5/3)
%using non-zero Bo data
%Vg = 1e-3 in this case: Vg = Xc^4/1e11
load('Dynamic_Vg_1e-11_Xinf_1000_Alpha_100.mat')

Vg = Xc^2/H_inf^4
A  = Xc^2/H_inf
t  = t*Vg^(-1/3)*A^(-5/3);

figure(1)
h_ridge = (y(:,N1)*dxf(N1+3) + y(:,N1+1)*dxf(N1+2))/(dxf(N1+2)+dxf(N1+3)); % because of nonuniform grid spacing
loglog(t,h_ridge,'r','LineWidth',1.5); hold on



maxt=max(t)
logmaxt=floor(log10(maxt))

discrete = 6;                % Plot 6 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = xf(2:N+1)-xf(1:N);      %% xf are grid points

% tgoal=logspace(logmaxt-2*discrete+2,logmaxt,discrete); % the target values of t that we want to be logarithmically spaced (for now)
tgoal=logspace(4,9,discrete); % the target values of t that we want to be logarithmically spaced (for now)

for j = 1:discrete-1
    tgoalNow=tgoal(j)
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);

    % Want to locate the minimum thickness in the positive region
    inds=find(x>Xc);
    [hmin,imin]=min(y(iplot,inds));
    imin=imin+min(inds)-1;
    xmin=x(imin);
        
    % Want to locate the minimum thickness in the inner region
    inds2=find(x<Xc);
    [hmin2,imin2]=min(y(iplot,inds2));
    imin2=imin2+min(inds2)-1;
    xmin2=x(imin2);
    
    %find bulge maximum
    inds=find(x>x(imin));
    [hmax,imax]=max(y(iplot,inds));
    imax=imax+min(inds)-1;
    xmax=x(imax);
    
    figure(1001)
        plot(x/Xc,y(iplot,:)/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on
        plot(xmin/Xc,hmin/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on
        plot(xmax/Xc,hmax/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
end
figure(1001)
    load('Static_Vg_1e-11_Xinf_1000_Alpha_100.mat')
    plot(sol.x/Xc,sol.y(1,:)/H_inf,'k--','LineWidth',0.8); hold on
    
    xlabel('$X=x/x_c$','interpreter','latex','fontsize',12);
    ylabel('$H=h/h_0$','interpreter','latex','fontsize',12);
    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'log')
    
    axis([1e-1 1e3 2e-3 7e1])
    hold off
    
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
%     tx = text(3e-1,1e1,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    tx = text(3e-1,2e0,'$\mathcal{V}_\gamma=10^{-3}$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)

    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.0f'),num2str(log10(tgoal(2)),'%.0f'),num2str(log10(tgoal(3)),'%.0f'),num2str(log10(tgoal(4)),'%.0f'),num2str(log10(tgoal(5)),'%.0f'),num2str(log10(tgoal(6)),'%.0f')},'fontsize',10,'Location','northoutside');
    set(c,'TickLabelInterpreter','latex');
%% note that Vg = Xc^2/H_inf^4; A = Xc^2/H_inf; Tnew = T*Vg^(-1/3)*A^(-5/3)
%%using non-zero Bo data
% Vg = 1e-5 in this case: Vg = Xc^4/1e13
load('Dynamic_Vg_1e-13_Xinf_1000_Alpha_100.mat')

Vg = Xc^2/H_inf^4
A  = Xc^2/H_inf
t  = t*Vg^(-1/3)*A^(-5/3);

figure(1)
h_ridge = (y(:,N1)*dxf(N1+3) + y(:,N1+1)*dxf(N1+2))/(dxf(N1+2)+dxf(N1+3)); % because of nonuniform grid spacing
loglog(t,h_ridge,'r','LineWidth',1.5); hold on



maxt=max(t)
logmaxt=floor(log10(maxt))

discrete = 6;                % Plot 6 curves
c        = parula(discrete); % Set color vector
Profile  = y';                     %% profiles
Deltax   = xf(2:N+1)-xf(1:N);      %% xf are grid points

% tgoal=logspace(logmaxt-2*discrete+2,logmaxt,discrete); % the target values of t that we want to be logarithmically spaced (for now)
tgoal=logspace(4,9,discrete); % the target values of t that we want to be logarithmically spaced (for now)

for j = 1:discrete-1
    tgoalNow=tgoal(j)
    inds=find(t<tgoalNow);
    iplot=max(inds);
    tplot=t(iplot);

    % Want to locate the minimum thickness in the positive region
    inds=find(x>Xc);
    [hmin,imin]=min(y(iplot,inds));
    imin=imin+min(inds)-1;
    xmin=x(imin);
        
    % Want to locate the minimum thickness in the inner region
    inds2=find(x<Xc);
    [hmin2,imin2]=min(y(iplot,inds2));
    imin2=imin2+min(inds2)-1;
    xmin2=x(imin2);
    
    %find bulge maximum
    inds=find(x>x(imin));
    [hmax,imax]=max(y(iplot,inds));
    imax=imax+min(inds)-1;
    xmax=x(imax);
    
    figure(1001)
        plot(x/Xc,y(iplot,:)/H_inf,'-','LineWidth',1,'Color',c(j,:)); hold on
        plot(xmin/Xc,hmin/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on
        plot(xmax/Xc,hmax/H_inf,'ro','MarkerSize',3,'MarkerEdgeColor','k'); hold on
end
figure(1001)
    load('Static_Vg_1e-13_Xinf_1000_Alpha_100.mat')
    plot(sol.x/Xc,sol.y(1,:)/H_inf,'k--','LineWidth',0.8); hold on
    
    xlabel('$X=x/x_c$','interpreter','latex','fontsize',12);
    ylabel('$H=h/h_0$','interpreter','latex','fontsize',12);
    set(gca, 'YScale', 'log')
    set(gca, 'XScale', 'log')
    
    axis([1e-1 1e3 2e-3 7e1])
    hold off
    
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
%     tx = text(3e-1,1e1,'$\mathrm{log}_{10}\,T$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)
    tx = text(3e-1,2e0,'$\mathcal{V}_\gamma=10^{-5}$','FontSize',11,'interpreter','latex'); set(tx,'Rotation',0)

    c = colorbar('Ticks',[0,0.2,0.4,0.6,0.8,1],'TickLabels',{num2str(log10(tgoal(1)),'%.0f'),num2str(log10(tgoal(2)),'%.0f'),num2str(log10(tgoal(3)),'%.0f'),num2str(log10(tgoal(4)),'%.0f'),num2str(log10(tgoal(5)),'%.0f'),num2str(log10(tgoal(6)),'%.0f')},'fontsize',10,'Location','northoutside');
    set(c,'TickLabelInterpreter','latex');
    