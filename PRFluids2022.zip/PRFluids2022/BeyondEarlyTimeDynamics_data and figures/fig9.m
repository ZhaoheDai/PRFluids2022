%%
c        = parula(3); % Set color vector
col1=c(1,:);col2=c(2,:);col3=c(3,:);
load('OtherData.mat')
figure(91)
    loglog(t1,h1,'LineWidth',0.9,'color',col1);hold on
    loglog(t2,h2,'LineWidth',0.9,'color',col2);hold on
    loglog(t3,h3,'LineWidth',0.9,'color',col3);hold on
xlabel('$T$','interpreter','latex','fontsize',12);
ylabel('${H_c-1}$','interpreter','latex','fontsize',12);


        xval = logspace(-6.5,-4.5,10);
        loglog(xval,45*(xval).^(1/4),'k-','LineWidth',0.8);hold on
        loglog(xval,45*(xval(end)).^(1/4)+0*xval,'k-','LineWidth',0.8);hold on
        loglog(xval(1)+0*xval,45*(xval).^(1/4)+0*xval,'k-','LineWidth',0.8);hold on

        xval = logspace(2.5,5,10);
        loglog(xval,3.5*(xval).^(1/5),'k-','LineWidth',0.8);hold on
        loglog(xval,3.5*(xval(end)).^(1/5)+0*xval,'k-','LineWidth',0.8);hold on
        loglog(xval(1)+0*xval,3.5*(xval).^(1/5)+0*xval,'k-','LineWidth',0.8);hold on

        
axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.XLim = [1e-7 1e9];
ax.YLim = [3e-1 1e2];
tx = text(10^(-6.4),1.7e0,'$1$','FontSize',10,'interpreter','latex'); 
tx = text(10^(-5.8),4e0,'$4$','FontSize',10,'interpreter','latex');
tx = text(10^(2.6),2.2e1,'$1$','FontSize',10,'interpreter','latex');
tx = text(10^(3.6),4.8e1,'$5$','FontSize',10,'interpreter','latex');

figure(92)
    loglog(t4,h4,'r:','LineWidth',0.9,'color',col3);hold on
    loglog(t5,h5,'r-','LineWidth',0.9,'color',col3);hold on
    loglog(t6,h6,'r--','LineWidth',0.9,'color',col3);hold on
    loglog(t7,h7,'r:','LineWidth',0.9,'color',col2);hold on
    loglog(t8,h8,'r-','LineWidth',0.9,'color',col2);hold on
    loglog(t9,h9,'r--','LineWidth',0.9,'color',col2);hold on
    loglog(t10,h10,'r:','LineWidth',0.9,'color',col1);hold on
    loglog(t11,h11,'r-','LineWidth',0.9,'color',col1);hold on
    loglog(t12,h12,'r--','LineWidth',0.9,'color',col1);hold on
xlabel('$T$','interpreter','latex','fontsize',12);
ylabel('${H_c-1}$','interpreter','latex','fontsize',12);
        
        
axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.XLim = [1e-7 1e9];
ax.YLim = [3e-1 1e2];



