%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CSD Jacobian J (see Shampine (2007))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dfdu = J(t,y)
%
global ng Si Sj ny index one2ny g
Y        = repmat(y,1,ng);
p        = y;
nrmy     = norm(y);  
p(y==0)  = nrmy; 
p        = eps*p; 
Y(index) = Y(index) + complex(0,1)*p;
%
Jac      = zeros(ny,ng);
for col = ng:-1:1
Jac(:,col) = imag( f(t,Y(:,col)) );
end
%
nf    = length(Jac(:,1));
Jac   = sparse(Si,Sj,Jac((g(Sj)-1)*nf + Si),nf,ny);
dfdu  = Jac * sparse(one2ny,one2ny,1 ./ p ,ny,ny);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End Jacobian J
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%