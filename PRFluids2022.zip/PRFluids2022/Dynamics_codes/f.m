function out = f(t,y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global N Bo pre dxf

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter definition ends
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% y, length N, i.e., interior points

% We use second-order finite differences, with the fluxes calculated at the
% grid point of the cells
% We add two ghost cells at each end to implement the boundary conditions
% In draft, h for H;

h             = zeros(N+4,1);     % total length of h: 2 ghost cells on each side                      
h(3:N+2)      = y(1:N);

% Boundary conditions on the left side of the inner meniscus

h(1)          = h(3)+2*dxf(3)/(dxf(3)+dxf(4))*(h(4)-h(3)); 
h(2)          = h(3);  

% Boundary conditions on the right side of the outer meniscus

h(N+3)        = h(N+2);
h(N+4)        = h(N+2)-2*dxf(N+2)/(dxf(N+1)+dxf(N+2))*(h(N+2)-h(N+1));

% Flux
out           = zeros(N,1);

hgrid         = zeros(N+3,1); %height at grid points, N+3
hgrid         = (dxf(2:N+4).*h(1:N+3)+dxf(1:N+3).*h(2:N+4))./(dxf(1:N+3)+dxf(2:N+4));

hx            = zeros(N+3,1); %slope at grid points; N+3 
hx            = 2*(h(2:N+4)-h(1:N+3))./(dxf(1:N+3)+dxf(2:N+4));

hxx           = zeros(N+2,1); %hxx at interior points
hxx           = (hx(2:N+3)-hx(1:N+2))./dxf(2:N+3);

hxxx          = zeros(N+1,1); % hxxx at grid points
hxxx          = 2*(hxx(2:N+2)-hxx(1:N+1))./(dxf(2:N+2)+dxf(3:N+3));

Q             = zeros(N+1,1);
Q             = hgrid(2:N+2).^3.*pre - hgrid(2:N+2).^3.*hxxx+(3./hgrid(2:N+2)+Bo*hgrid(2:N+2).^3).*hx(2:N+2);
% Q             = hgrid(2:N+2).^3.*pre - hgrid(2:N+2).^3.*hxxx+(Bo*hgrid(2:N+2).^3).*hx(2:N+2); % remove vdW force
out(1:N)      = 1./dxf(3:N+2).*(Q(2:N+1)-Q(1:N));
end
