%%This code is based on the old version of non-dimensionalization, which
%%can be seen in "Push-and-pull a thin film -> main" file in overleaf. 
%%The new version can be found in "Push-and-pull a thin film_revised" file.
tic

global N Xc Bo H_inf X_inf dx epsi pre dxf

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Parameter definitions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%set up controlling parameter in manuscript
A        = 100;  %aspect ratio
Vg       = A^4/10^(12);
Bnew     = 1e-2;
n        = 1000;             % X_inf in new version
%%controlling parameter in old version
Bo       = Bnew*Vg^(1/3)*A^(-4/3)
% Bo       = 0;              % normalized initial height
Xc       = Vg^(-1/6)*A^(2/3) % i.e. x_c/lvdw, normalized position of contact line
H_inf    = Vg^(-1/3)*A^(1/3) % i.e. h0/h_eqm
epsi     = Xc/100;           % delta function width at the contact line
X_inf    = n*Xc;             % size of the film, including outer

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End parameter definitions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Grid definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T0          = 0;                     % Start time
T1          = 1e6;                   % End time (vary depending on parameters)
tspan       = [T0 T1];
tspan       = [0 logspace(-8,log10(T1),2000)];
N1          = 90*10;                 % inner points, x < Xc
% N1          = 100*100;             % inner points, x < Xc
N2          = 100*80;               % outer points, x > Xc
N           = N1 + N2;               % N interior points, i.e., N+1 grid points

xf          = zeros(N+1,1);          % flux grid points
xf(1:N1+1)  = Xc*log10(1:9/N1:10);   % from 0 to Xc
% xf(1:N1+1)= Xc*log10(log2(2:(2^10-2)/N1:2^10));  % from 0 to Xc,logB(X) = logA(X) / logA(B)
xf(N1+1:N+1)= Xc*10.^(0:log10(n)/N2:log10(n));   % from Xc to n*Xc
% xf(N1+1:N+1)= Xc*40.^(0:log10(n)/log10(40)/N2:log10(n)/log10(40));   % from Xc to n*Xc

x          = zeros(N,1);             % half-grid interior points
x          = (xf(1:N)+xf(2:N+1))/2;         
pre_i      = 1/2*(1 + tanh((Xc-x)/epsi))-Xc/2/epsi*(sech((x-Xc)/epsi)).^2; % pressure
pre        = -1/2/epsi^2*(sech((xf-Xc)/epsi)).^2.*(epsi + 2*Xc*tanh((Xc-xf)/epsi)); % dp/dx
H0         = zeros(N,1) + H_inf;

% for function use, where there are N+5 grid points so N+4 cells
dxf        = zeros(N+4,1);                % spacing between grid points
dxf(3:N+2) = xf(2:N+1)-xf(1:N);           % real points
dxf(1) = dxf(3); dxf(2) = dxf(3);         % RHS ghost points 
dxf(N+3) = dxf(N+2); dxf(N+4) = dxf(N+2); % LHS ghost points 
% sum(dxf(3:N+2).*pre_i)% check pressure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End grid definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Sparsity pattern
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %size(S) = N*N
S                   = spdiags(ones(N,5),-2:2,N,N);
global ng Si Sj ny index one2ny g
g                   = colgroup(S); 
ng                  = max(g);
[Si Sj]             = find(S);
ny                  = N;
one2ny              = (1:ny)';
index               = (g-1)*ny + one2ny;
% % 5 diagional columns (from finite difference formualae)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End sparsity pattern
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options = odeset('RelTol',1e-7,'AbsTol',1e-7,'Stats','on','Jacobian',@J,'MaxStep',1e11);
% options = odeset('RelTol',1e-7,'AbsTol',1e-7,'Stats','on');
[t,y]   = ode15s(@f,tspan,H0,options);
sol.x   = t;
sol.y   = y';
loglog(x,y(1,1:N),'b--','LineWidth',1)
hold on
loglog(x,y(length(t),1:N),'r--','LineWidth',1)
hold on
xlabel('x')
ylabel('height')  

%print the following
t(end)
length_t  = length(t);
RelVol    = (sum(dxf(3:N+2).*y(length_t,:)')- X_inf*H_inf)/X_inf/H_inf

toc

%% plot the center point

% evolution of the ridge height
h_ridge = (y(:,N1)*dxf(N1+3) + y(:,N1+1)*dxf(N1+2))/(dxf(N1+2)+dxf(N1+3)); % because of nonuniform grid spacing

loglog(t,sol.y(1,:),'r','LineWidth',1.5); hold on

xlabel('$T$','interpreter','latex');
% ylabel('${H(X_c,T)-H_\infty}$','interpreter','latex');
% text(10,10,'$\epsilon = X_c/20$','FontSize',10,'interpreter','latex');


