% In draft, H_inf is H_0

c        = parula(6); % Set color vector
col1=c(1,:);col2=c(3,:);col3=c(5,:);

%% evolution of the ridge height for separated method
%%%To save space, we only provide the "TrueDelta_X_inf_100_X_c_100.mat"
% load('TrueDelta_X_inf_10_X_c_100.mat')
%     s       = Xc^2/H_inf; %aspect ratio
%     h_ridge = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
%     loglog(sol.x*H_inf^3/Xc^4*s^4,(h_ridge-H_inf)/H_inf,'LineWidth',0.8,'Color',col1); hold on % for H_* and T_*
    load('TrueDelta_X_inf_100_X_c_100.mat')
    h_ridge = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
    loglog(sol.x*H_inf^3/Xc^4*s^4,(h_ridge-H_inf)/H_inf,'--','LineWidth',0.8,'Color',col3); hold on % for H_* and T_*
% load('TrueDelta_X_inf_10_X_c_141.mat')
%     s       = Xc^2/H_inf; %aspect ratio
%     h_ridge = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
%     loglog(sol.x*H_inf^3/Xc^4*s^4,(h_ridge-H_inf)/H_inf,'LineWidth',0.8,'Color',col1); hold on % for H_* and T_*
%     load('TrueDelta_X_inf_100_X_c_141.mat')
%     h_ridge = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
%     loglog(sol.x*H_inf^3/Xc^4*s^4,(h_ridge-H_inf)/H_inf,'--','LineWidth',0.8,'Color',col3); hold on % for H_* and T_* 
% load('TrueDelta_X_inf_10_X_c_200.mat')
%     s       = Xc^2/H_inf; %aspect ratio
%     h_ridge = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
%     loglog(sol.x*H_inf^3/Xc^4*s^4,(h_ridge-H_inf)/H_inf,'LineWidth',0.8,'Color',col1); hold on % for H_* and T_*
%     load('TrueDelta_X_inf_100_X_c_200.mat')
%     h_ridge = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
%     loglog(sol.x*H_inf^3/Xc^4*s^4,(h_ridge-H_inf)/H_inf,'--','LineWidth',0.8,'Color',col3); hold on % for H_* and T_*    

%%%FT prediction    
px = 10.^(-3:0.1:3);
py = sqrt(2/pi)*sqrt(pi)/gamma(1/4)*px.^(1/4);
loglog(px,py,'k--','LineWidth',0.8); hold on % for H_* and T_*
hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)

xlabel('$T_*$','interpreter','latex','fontsize',12);
ylabel('$H_{c\ast}-1$','interpreter','latex','fontsize',12);
% ax.YLim = [1e-1 1e4];
ax.XLim = [1e-3 1e10];
ax.YLim = [7e-2 5e0];
lgd = legend('$x_\infty=100\,x_c$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);
text(0.1,1,'$\sim T_*^{1/4}$','FontSize',8,'interpreter','latex');
% text(0.1,0.01,'$S=50$','FontSize',8,'interpreter','latex');
% text(0.1,0.01,'$S=100$','FontSize',8,'interpreter','latex');
% text(0.1,0.01,'$S=200$','FontSize',8,'interpreter','latex');
% text(0.1,1,'$\mathrm{increasing~}\mathcal{F}$','FontSize',8,'interpreter','latex');

%%
numb = 1000;

col=[255 230 152]/255; %gray

plot(x,sol.y(1:N,1),'--','LineWidth',1,'Color',col)
hold on
plot(x,sol.y(1:N,numb),'-','LineWidth',1,'Color',col)
hold on


ar = area(x,sol.y(1:N,numb)); hold on
ar.FaceColor = [235 221 195]/255;
[M1,pos_d1] = min(sol.y(1:N1+1,numb));
[M2,pos_d2] = min(sol.y(N1+1:N,numb));
[M3,pos_c]  = max(sol.y(1:N,numb));

plot(x(pos_d1),M1,'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col); hold on
plot(x(N1+pos_d2),M2,'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col); hold on
plot(x(pos_c),M3,'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col); hold on


% plot(x,sol.y(1:N,numb),'LineWidth',1,'Color',col)
% hold on
% plot(x,sol.y(1:N,1),'k--','LineWidth',1)
% hold on
% 
% xlabel('x')
% ylabel('height')  
lgd = legend('$\mathrm{Initial}$','$\mathrm{Deformed}$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',7.5);

text(100,100,'$\left(\alpha,\tilde H_{c} \right)$','FontSize',7,'interpreter','latex');
text(100,100,'$\left(\tilde X_\mathrm{min}^-,\tilde H_\mathrm{min}^- \right)$','FontSize',7,'interpreter','latex');
text(100,100,'$\left(\tilde X_\mathrm{min}^+,\tilde H_\mathrm{min}^+ \right)$','FontSize',7,'interpreter','latex');

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.5)
% set(gca, 'YScale', 'log')
ax.YLim = [10 300];
ax.XLim = [60 600];
axis off;
