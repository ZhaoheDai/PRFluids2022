% In draft, H_inf is H_0
c        = parula(3); col1=c(2,:);
c        = parula(8); col2=c(7,:);
%% evolution of the dimple minima
    load('TrueDelta_X_inf_100_X_c_100.mat')
    
tt=tiledlayout(2,1)
tt.TileSpacing = 'none';
ax = nexttile;

pos_d1     = zeros(1,length_x);   %position of the inner dimple
X_d1       = zeros(1,length_x);
M1         = zeros(1,length_x);   %minimun of the inner meniscus
pos_d2     = zeros(1,length_x);   %position of the outer dimple
X_d2       = zeros(1,length_x);
M2         = zeros(1,length_x);   %minimun of the inner meniscus

[M1,pos_d1] = min(sol.y(1:N1+1,:));
[M2,pos_d2] = min(sol.y(N1+1:N,:));


for j =1:length_x
   X_d1(j)       = x(pos_d1(j));
   X_d2(j)       = x(N1+pos_d2(j));
end
s       = Xc^2/H_inf;
loglog(sol.x(2:length_x)*H_inf^3/Xc^4*s^4,M1(2:length_x)/H_inf,'LineWidth',0.9,'Color',col1);hold on %for T_* and H_*
loglog(sol.x(2:length_x)*H_inf^3/Xc^4*s^4,M2(2:length_x)/H_inf,'LineWidth',0.9,'Color',col2);hold on

%%power law for the dimple minima
px = 10.^(-2:0.1:4);
py = 1 - 0.305/pi*px.^(1/4);
loglog(px,py,'k--','LineWidth',0.9); hold on % for H_* and T_*
%%the h_eqm line
px = 10.^(4:0.1:8);
py = 0*px.^(1/4)+1/H_inf;
loglog(px,py,'k--','LineWidth',0.9); hold on % for H_* and T_*

text(1e2,0.5,'$1 - 0.305\,T_*^{1/4}/\pi$','FontSize',11,'interpreter','latex')
text(1e2,0.1,'$\left(\mathcal V_\gamma/\alpha\right)^{1/3}$','FontSize',11,'interpreter','latex');
text(1,0.1,'$\mathrm{inner}$','FontSize',10,'interpreter','latex','color',col1);
text(1,0.1,'$\mathrm{outer}$','FontSize',10,'interpreter','latex','color',col2);

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.XLim = [1e-2 1e8];
ax.YLim = [8e-3 1e0];
ylabel('$\tilde H_\mathrm{min}^{\pm}$','interpreter','latex','fontsize',12);
set(ax,'XTicklabels',[]);
%% evolution of the dimple positions
    load('TrueDelta_X_inf_100_X_c_100.mat')

ax = nexttile;

loglog(sol.x(2:length_x)*H_inf^3/Xc^4*s^4,abs(X_d1(2:length_x)-Xc)/Xc*s,'LineWidth',0.9,'Color',col1);hold on
loglog(sol.x(2:length_x)*H_inf^3/Xc^4*s^4,abs(X_d2(2:length_x)-Xc)/Xc*s,'LineWidth',0.9,'Color',col2);hold on

%%power law for the dimple position
px = 10.^(-2:0.1:4);
py = 2.3*px.^(1/4);
loglog(px,py,'k--','LineWidth',0.9); hold on % for H_* and T_*

text(1e3,1,'$2.3\,T_*^{1/4}$','FontSize',11,'interpreter','latex');
text(1,1,'$\mathrm{inner}$','FontSize',10,'interpreter','latex','color',col1);
text(1,1,'$\mathrm{outer}$','FontSize',10,'interpreter','latex','color',col2);

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.XLim = [1e-2 1e8];
ax.YLim = [7e-1 1e2];
xlabel('$T_*$','interpreter','latex','fontsize',12);
ylabel('$\left|\tilde X_\mathrm{min}^{\pm}-\alpha\right|$','interpreter','latex','fontsize',12);


%% evolution of the rotation angle
    load('TrueDelta_X_inf_100_X_c_100.mat')

tt=tiledlayout(2,1)
tt.TileSpacing = 'none';
ax = nexttile;

rotat        = zeros(1,length_x);
slope1       = zeros(1,length_x);
slope2       = zeros(1,length_x);

%method 1
slope1   = (-((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)) - sol.y(N1,:))/d2;
slope2   = (sol.y(N1+1,:)+((-2*d7*sol.y(N1,:) - d2*sol.y(N1+1,:) + d7*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/d7;
rotat    = (slope1+slope2)/2/Xc;

%method 2
h_ridge  = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
slope1   = (h_ridge - sol.y(N1,:))/(d2/2);
slope2   = (sol.y(N1+1,:) - h_ridge)/(d7/2);
rotat    = (slope1+slope2)/2/Xc;

loglog(sol.x*H_inf^3/Xc^4*s^4,rotat,'k-','LineWidth',0.9);hold on

%%%FT power law
px = 10.^(-2:0.1:2);
py = gamma(3/4)/pi/s*px.^(1/4);
loglog(px,py,'k--','LineWidth',0.9); hold on % for H_* and T_*
text(1,0.1,'$\sim T_*^{1/4}/\alpha$','FontSize',11,'interpreter','latex');

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim = [1e-2 1e8];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
% set(gca,'XScale','log')
ylabel('$\Delta\theta$','interpreter','latex','fontsize',12);
set(ax,'XTicklabels',[]);
%% evolution of liquid fraction in the ridge
    load('TrueDelta_X_inf_100_X_c_100.mat')

ax = nexttile;

V_ridge    = zeros(1,length_x);
V_drop     = zeros(1,length_x);

h_ridge    = (sol.y(N1,:) - ((d2*sol.y(N1,:) - d7*sol.y(N1,:) - 2*d2*sol.y(N1+1,:) - d2*d7*Xc)/(d2 + d7)))/2;
dxx        = xf(2:N+1)-xf(1:N);% interval length

[M1,pos_d1] = min(sol.y(1:N1+1,:));
[M2,pos_d2] = min(sol.y(N1+1:N,:));

for j = 1:1:length_x
    profile                 = sol.y(:,j);
    profile(1:pos_d1(j))    = 0;
    profile(N1+pos_d2(j):N) = 0;
    profile                 = profile - H_inf;
%     plot(x,profile); hold on
    profile(profile<0)      = 0; % make negative values zero
%     plot(x,profile); hold on
    V_ridge(j)              = sum(dxx.*profile);
    V_drop(j)               = Xc*H_inf - sum(dxx(1:N1).*sol.y(1:N1,j));
end

yyaxis left
loglog(sol.x*H_inf^3/Xc^4*s^4,V_ridge/Xc/H_inf,'LineWidth',0.9,'Color',col1);hold on

%%the slope
plot(10.^(-1:0.1:1),(10.^(-1:0.1:1)).^0.5/100,'k-','LineWidth',0.75)
plot(10.^(-1:0.1:1),(10^(1)).^0.5/100*(10.^(-1:0.1:1)).^0,'k-','LineWidth',0.75)
plot([10^(-1) 10^(-1)],[1/100*(10^(-1)).^0.5 1/100*(10^(1)).^0.5],'k-','LineWidth',0.75)
text(1,0.1,'$1$','FontSize',11,'interpreter','latex','Color','k');
text(1,0.1,'$2$','FontSize',11,'interpreter','latex','Color','k');

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.YAxis(1).Color = col1;
ax.XLim = [1e-2 1e8];
% ax.YLim = [3e1 1e3];
xlabel('$T_*$','interpreter','latex','fontsize',12);
ylabel('$V_\mathrm{skirt}$','interpreter','latex','fontsize',12);
% set(gca, 'XScale', 'log')
% text(0.1,0.1,'$V_\mathrm{skirt}$','FontSize',11,'interpreter','latex','Color',col1);
% text(0.1,0.1,'$V_\mathrm{drop}$','FontSize',11,'interpreter','latex','Color',col2);

yyaxis right
loglog(sol.x*H_inf^3/Xc^4*s^4,(V_drop./V_ridge),'LineWidth',0.9,'Color',col2);hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
ax.XLim = [1e-2 1e8];
ax.YAxis(2).Color = col2;
% ax.YLim = [3e1 1e3];
xlabel('$T_*$','interpreter','latex','fontsize',12);
ylabel('$V_\mathrm{drop}/V_\mathrm{skirt}$','interpreter','latex','fontsize',12);