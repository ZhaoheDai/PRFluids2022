This file contains the code for solving the PDEs in PRF2022 as well as for drawing figures shown in PRF2022.

The data file could be found in the ORA documents that would be linked to the paper by Z. Dai and D. Vella (NO54 in http://www2.coe.pku.edu.cn/subpaget.asp?id=746 or NO. 124 in https://people.maths.ox.ac.uk/vella/publications.html)