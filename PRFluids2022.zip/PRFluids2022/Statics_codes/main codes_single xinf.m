%%This code is based on the old version of non-dimensionalization, which
%%can be seen in "Push-and-pull a thin film -> main" file in overleaf. 
%%The new version can be found in "Push-and-pull a thin film_revised" file.
tic
global Xc H_inf Bo pf LSlope LineFRot
LSlope   = 1; %1 to include; 0 to ignore
LineFRot = 1; % cos(Dtheta) will rotate to be smaller than 1
pf_up    = Bo*H_inf; %upper limit of p_inf
pf_low   = -1;     %lower limit of p_inf - tunable
pf       = 0;
%%set up controlling parameter in manuscript

A        = 100;  %aspect ratio
Vg       = A^4/10^(12);
Bnew     = 1e-2;

%%controlling parameter in old version
Bo       = Bnew*Vg^(1/3)*A^(-4/3)
Xc       = Vg^(-1/6)*A^(2/3) % i.e. x_c/lvdw
H_inf    = Vg^(-1/3)*A^(1/3) % i.e. h0/h_eqm

% n        = 10^0.3;      
n        = 1000;
X_inf    = n*Xc;
dx1      = Xc/1000;
xmesh    = [0:dx1:Xc Xc*10.^(0:log10(n)/2000:log10(n))];

error_LF = 1;
while error_LF >1e-3
    
yinit    = [0.8;0.1];
sol      = bvpinit(xmesh,yinit);
options = bvpset('RelTol',1e-7,'Stats','off');
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

approx    = X_inf*H_inf;
computed  = 0;
for i     = 2:length(sol.x)
    computed = computed + (sol.x(i)-sol.x(i-1))*sol.y(1,i);
end
error     = (computed-approx)/approx

while abs(error)>1e-3
    if error > 0
        pf_up    = pf;
        pf       = (pf_up + pf_low)/2;
    else
        pf_low    = pf;
        pf       = (pf_up + pf_low)/2;
    end
    xmesh    = [0:dx1:Xc Xc*10.^(0:log10(n)/2000:log10(n))];
    yinit    = [0.8;0.1];
    sol      = bvpinit(xmesh,yinit);
    options = bvpset('RelTol',1e-7,'Stats','off');
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    approx    = X_inf*H_inf;
    computed  = 0;
    for i     = 2:length(sol.x)
        computed = computed + (sol.x(i)-sol.x(i-1))*sol.y(1,i);
    end
    error     = (computed-approx)/approx
end

%%%%%define the rotation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
slope1   = (sol.y(1,1001)-sol.y(1,1000))./(sol.x(1,1001)-sol.x(1,1000));
slope2   = (sol.y(1,1002)-sol.y(1,1003))./(sol.x(1,1002)-sol.x(1,1003));
rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
rotatang = asin(rotat);
error_LF = abs((cos(rotatang)-LineFRot)/LineFRot)
LineFRot = cos(rotatang);
pf_up    = Bo*H_inf;
pf_low   = -0.5;

end


toc

% yyaxis left
plot(sol.x,sol.y(1,:),'-','LineWidth',2); hold on
% legend('H','H_X')
xlabel({'X'})
ylabel('H')
% 
% yyaxis right
% plot(sol.x,sol.y(2,:),'--'); hold on
% xlabel({'X'})
% ylabel('H_X')
% legend('H','H_X')
axis on;
ax        = gca;
ax.XLim   = [0 5*Xc];


height    = (sol.y(1,end) - H_inf)/H_inf;
fprintf('%2i    %10.3f     %10.3f     %10.3f \n',approx,computed,(computed-approx)/approx,height);
toc


function dydx = f(x,y,region) % equations being solved
global H_inf Bo pf LSlope Xc LineFRot

dydx     = zeros(2,1);

dydx(1)  = y(2);

switch region
    case 1                    % x in [0 Xc]
        dydx(2) = (-pf + 1*LineFRot + Bo*y(1) - y(1)^(-3))*(1+LSlope*y(2)^2/Xc^2)^(3/2);
    case 2                    % x in [Xc X_inf]
        dydx(2) = (-pf + Bo*y(1) - y(1)^(-3))*(1+LSlope*y(2)^2/Xc^2)^(3/2);
end
end
%-------------------------------------------
function res = bc(YL,YR)      % boundary conditions
global Xc H_inf LSlope LineFRot
res = [YL(2,1) - 0            % H'(0) = 0
       YR(1,1) - YL(1,2)      % Continuity of H(x) at X = Xc
       YR(2,1)/(1+LSlope*YR(2,1)^2/Xc^2)^(1/2) - YL(2,2)/(1+LSlope*YL(2,2)^2/Xc^2).^(1/2) - Xc*LineFRot % H'(X_c) - H at x = 1
       YR(2,2) - 0];          % H'(H_inf) = 10
end
%-------------------------------------------
