%%This code is based on the old version of non-dimensionalization, which
%%can be seen in "Push-and-pull a thin film -> main" file in overleaf. 
%%The new version can be found in "Push-and-pull a thin film_revised" file.

% may run [main codes_single xinf] for Xinf = n = 10^0.3 and 10^4 to 
% see whether the cycle works with the guessed pf_low and how long
% my experience is that pf_low   = -5 is safe enough for all cases

tic
global Xc H_inf Bo pf LSlope LineFRot Grav Bond
LSlope   = 1; %1 to include; 0 to ignore
Grav     = 1; %1 to include the gravity of the drop
%%set up controlling parameter in manuscript

A        = 100; Bond = 1e-2; Vg = 1e-4;

%%controlling parameter in old version
Xc       = Vg^(-1/6)*A^(2/3);
Bo       = Bond*Vg^(1/3)*A^(-4/3);
H_inf    = Vg^(-1/3)*A^(1/3);
% Xc       = 100;                      % Define drop radius
% Bo       = 1e-14*Xc^4;               % Define Bond number that is related to drop radius
% H_inf    = 10^5/Xc;                  % Define h_inf which is tunable
nXc      = 10.^(0.3:0.1:4);          % Define X_inf = nXc*Xc
% hXc      = zeros(1,length(nXc));     % The skirt height
% x_rec    = zeros(length(nXc),3002);  % Record X for each X_inf, 3002 is due to length of sol.x
% y_rec    = zeros(length(nXc),3002);  % Record H(X) for each X_inf

pf_up    = Bo*H_inf;                 %Used for the first cycle, to be updated after each cycle
pf_low   = -10;                       %Tune accoridng to the Testing
pf       = -1.5;
pf_upr   = Bo*H_inf;       % The upper limit
pf_lowr  = -10;
LineFRot =1;

for j    = 10:length(nXc)
    X_inf    = nXc(j)*Xc;
    dx1      = Xc/1000;
    xmesh    = [0:dx1:Xc Xc*10.^(0:log10(nXc(j))/2000:log10(nXc(j)))];
    yinit    = [0.8;0.1];
    error_LF = 1;
    while error_LF >1e-3
    sol      = bvpinit(xmesh,yinit);
    options = bvpset('RelTol',1e-7,'Stats','off');
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);

    approx    = X_inf*H_inf;
    computed  = 0;
    for i     = 2:length(sol.x)
        computed = computed + (sol.x(i)-sol.x(i-1))*sol.y(1,i);
    end
    error     = (computed-approx)/approx

    while abs(error)>5e-3
    if error > 0
        pf_up    = pf;
        pf       = (pf_up + pf_low)/2;
    else
        pf_low    = pf;
        pf       = (pf_up + pf_low)/2;
    end
    xmesh    = [0:dx1:Xc Xc*10.^(0:log10(nXc(j))/2000:log10(nXc(j)))];
    yinit    = [0.8;0.1];
    sol      = bvpinit(xmesh,yinit);
    options = bvpset('RelTol',1e-6,'Stats','off');
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    sol = bvp5c(@(x,y,r) f(x,y,r), @bc, sol, options);
    
    approx    = X_inf*H_inf;
    computed  = 0;
    for i     = 2:length(sol.x)
        computed = computed + (sol.x(i)-sol.x(i-1))*sol.y(1,i);
    end
    error     = (computed-approx)/approx
    end
    %%%%%define the rotation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    slope1   = (sol.y(1,1001)-sol.y(1,1000))./(sol.x(1,1001)-sol.x(1,1000));
    slope2   = (sol.y(1,1002)-sol.y(1,1003))./(sol.x(1,1002)-sol.x(1,1003));
    rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
    rotatang = asin(rotat);
    error_LF = abs((cos(rotatang)-LineFRot)/LineFRot)
    LineFRot= cos(rotatang);
    pf_up    = pf_upr;
    pf_low   = pf_lowr;
    end
    x_rec(j,:) = sol.x(:);
    y_rec(j,:) = sol.y(1,:);
    t_rec(j,:) = rotatang;    
    hXc(j)     = sol.y(1,1001);
    pf_upr      = Bo*H_inf;       % The upper limit
    pf_lowr     = -2*abs(pf);             % For the next X_inf, pf would increase
    pf         = (pf_lowr+pf_upr)/2;         
    j
end


toc

plot(nXc,hXc,'-','LineWidth',2); hold on




function dydx = f(x,y,region) % equations being solved
global H_inf Bo pf LSlope Xc LineFRot Grav Bond

dydx     = zeros(2,1);

dydx(1)  = y(2);

switch region
%     case 1                    % x in [0 Xc]
%         dydx(2) = -pf + 1 + Bo*(y(1) - H_inf) + H_inf^(-3) - y(1)^(-3);
%     case 2                    % x in [Xc X_inf]
%         dydx(2) = -pf + Bo*(y(1) - H_inf) + H_inf^(-3) - y(1)^(-3);
    case 1                    % x in [0 Xc]
        dydx(2) = (-pf + 1*LineFRot + Grav*Bond + Bo*y(1) - y(1)^(-3))*(1+LSlope*y(2)^2/Xc^2)^(3/2);
    case 2                    % x in [Xc X_inf]
        dydx(2) = (-pf + Bo*y(1) - y(1)^(-3))*(1+LSlope*y(2)^2/Xc^2)^(3/2);
end
end
%-------------------------------------------
function res = bc(YL,YR)      % boundary conditions
global Xc H_inf LSlope LineFRot
res = [YL(2,1) - 0            % H'(0) = 0
       YR(1,1) - YL(1,2)      % Continuity of H(x) at X = Xc
       YR(2,1)/(1+LSlope*YR(2,1)^2/Xc^2)^(1/2) - YL(2,2)/(1+LSlope*YL(2,2)^2/Xc^2).^(1/2) - Xc*LineFRot % H'(X_c) - H at x = 1
       YR(2,2) - 0];          % H'(H_inf) = 0
end
%-------------------------------------------
