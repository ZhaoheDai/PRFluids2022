%% static meniscus
ms = 'MarkerSize'; msn = 4; lw = 'LineWidth';  lwn = 0.8;
col=[0.501960784313725 0.501960784313725 0.50196]; %gray

% for schellenberger 2015, capillary length rho = 1.93, gamma= 17.9 mN/m lc = sqrt(17.9/9.8/1.93)
load('Schellenberger2015.mat')
lc = sqrt(17.9/9.8/1.93);
l_half = 0.4824;
x1 = (Schellenberger2015(:,1))/1000/lc;
y1 = (Schellenberger2015(:,2))/(Schellenberger2015(1,2));
plot(x1,y1,'o','color','k',ms,msn,lw,lwn); hold on
% set(gca,'XScale','log')

% % for Kreder2018, capillary length rho = 0.971, gamma= 19 mN/m lc = sqrt(19/9.8/0.971)
% load('Kreder2018_static.mat')
% lc = sqrt(19/9.8/0.971);
% l_half = 0.011;
% x2 = (Kreder2018_static(1,1)-Kreder2018_static(:,1))/1000/l_half;
% y2 = Kreder2018_static(:,2) - Kreder2018_static(end,2);
% y2 = y2/y2(1);
% plot(x2,y2,'s','color','k',ms,msn); hold on
% 

xx = (0:0.1:3)+0.43; 
plot(xx,exp(-(0:0.1:3)),'color','k',lw,lwn); hold on % 1d model

yy = besselk(0,xx)/besselk(0,0.43);
plot(xx,yy,'k--',lw,lwn);


% lgd = legend('Schellenberger \emph{et al}. (2015)','$h/h_c=\exp{(-x/\ell_c)}/\exp{(-x_c/\ell_c)}$','$h/h_c=\mathrm{K_0}(x/\ell_c)/\mathrm{K_0}(x_c/\ell_c)$','interpreter','latex');

lgd = legend('Schellenberger \emph{et al}. (2015)','$h/h_c=\exp{[-(x-x_c)/\ell_c}]$','$h/h_c=\mathrm{K_0}(x/\ell_c)/\mathrm{K_0}(x_c/\ell_c)$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);

% tex=text(1,0.2,'{Schellenberger et al. (2015)}','FontSize',8,'interpreter','latex','color','k');
% set(tex,'Rotation',-45)
% 
% tex=text(1,0.2,'{Kreder et al. (2018)}','FontSize',8,'interpreter','latex','color','k');
% set(tex,'Rotation',0)
% 
% tex=text(1,0.2,'{Exponential decay}','FontSize',8,'interpreter','latex','color','k');
% set(tex,'Rotation',-33)

set(gca,'YScale','log')
% set(gca,'XScale','log')

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [0 3.5];
ax.YLim   = [1e-2 1.1];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$x/\ell_c$','interpreter','latex','fontsize',12);
ylabel('$h/h_c$','interpreter','latex','fontsize',12);
