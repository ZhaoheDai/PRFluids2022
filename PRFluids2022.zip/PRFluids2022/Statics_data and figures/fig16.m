% In draft, H_inf is H_0
% nXc = 10.^(0.3:0.1:4); % Define X_inf = nXc*Xc
c        = parula(3); % Set color vector
col1=c(1,:);col2=c(2,:);col3=c(3,:);
%% H @ Xc
tt=tiledlayout(2,1)
tt.TileSpacing = 'none';
ax = nexttile;
load('Vg_1e-4.mat')
plot(nXc,hXc/(H_inf)^0.5/Xc,'--','LineWidth',0.9,'color',col1); hold on
load('Vg_1e-2.mat')
plot(nXc,hXc/(H_inf)^0.5/Xc,'--','LineWidth',0.9,'color',col2); hold on
load('Vg_1e0.mat')
plot(nXc,hXc/(H_inf)^0.5/Xc,'--','LineWidth',0.9,'color',col3); hold on

load('Vg_1e-4_LargeSlope_Rotation.mat')
l1=plot(nXc,hXc/(H_inf)^0.5/Xc,'-','LineWidth',0.9,'color',col1); hold on
load('Vg_1e-2_LargeSlope_Rotation.mat')
l2=plot(nXc,hXc/(H_inf)^0.5/Xc,'-','LineWidth',0.9,'color',col2); hold on
load('Vg_1e0_LargeSlope_Rotation.mat')
l3=plot(nXc,hXc/(H_inf)^0.5/Xc,'-','LineWidth',0.9,'color',col3); hold on

% %%%small-skirt limit
% X_ana = 10.^(0:0.01:2); H_ana = sqrt(3/8)*(X_ana).^0.5;
% plot(X_ana,H_ana,'k-','LineWidth',1); hold on


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [1e1 1e4]; % down to 2X_c
ax.YLim   = [1.1 7]; 

set(gca,'XScale','log')
% set(gca,'YScale','log')

set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
% xlabel('$X_\infty=x_\infty/x_c$','interpreter','latex','fontsize',12);
ylabel('$H_c/\alpha^{1/2}$','interpreter','latex','fontsize',12);

% lgd = legend([l1 l2 l3],'$\mathcal{V}_\gamma = 10^{-4}$','$\mathcal{V}_\gamma = 10^{-2}$','$\mathcal{V}_\gamma = 10^{0}$','interpreter','latex');
% set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);

set(ax,'XTicklabels',[]);
%% volume
ax = nexttile;
load('Vg_1e-4.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - y_rec(i,end); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:end));
end
loglog(nXc,volume/Xc/H_inf,'--','LineWidth',0.9,'Color',col1); hold on

load('Vg_1e-2.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
loglog(nXc,volume/Xc/H_inf,'--','LineWidth',0.9,'Color',col2); hold on

load('Vg_1e0.mat')
lengx  =  length(x_rec(1,:)); dx(1:lengx-1) = x_rec(1,2:lengx)-x_rec(1,1:lengx-1);
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
loglog(nXc,volume/Xc/H_inf,'--','LineWidth',0.9,'Color',col3); hold on


load('Vg_1e-4_LargeSlope_Rotation.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - y_rec(i,end); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:end));
end
l1=loglog(nXc,volume/Xc/H_inf,'-','LineWidth',0.9,'Color',col1); hold on

load('Vg_1e-2_LargeSlope_Rotation.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
l2=loglog(nXc,volume/Xc/H_inf,'-','LineWidth',0.9,'Color',col2); hold on

load('Vg_1e0_LargeSlope_Rotation.mat')
lengx  =  length(x_rec(1,:)); dx(1:lengx-1) = x_rec(1,2:lengx)-x_rec(1,1:lengx-1);
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
l3=loglog(nXc,volume/Xc/H_inf,'-','LineWidth',0.9,'Color',col3); hold on

% %%%small-skirt limit
% X_ana = 10.^(0:0.01:2); v_ana = (X_ana);
% plot(X_ana,v_ana,'k-','LineWidth',1); hold on


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [1e1 10^4];
ax.YLim   = [5e0 2e3];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
% set(gca,'XScale','log')
lgd = legend([l1 l2 l3],'$\mathcal{V}_\gamma = 10^{-4}$','$\mathcal{V}_\gamma = 10^{-2}$','$\mathcal{V}_\gamma = 10^{0}$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);

xlabel('$X_\infty=x_\infty/x_c$','interpreter','latex','fontsize',12);
ylabel('$V_\mathrm{skirt}$','interpreter','latex','fontsize',12);  
