% In draft, H_inf is H_0
% nXc = 10.^(0.3:0.1:4); % Define X_inf = nXc*Xc
% Run this to define color
c        = parula(4); % Set color vector
col1=c(1,:); col2=c(2,:);col3=c(3,:);col4=c(4,:);
% c        = parula(3); % Set color vector
% col1=c(1,:);col2=c(2,:);col3=c(3,:);
%% Profiles for X_c = 100, H_0 = 100， and various X_inf
% Note that X_c = x_c/l_vdw and H_0 = h_0/h_eqm so X^NEW = X/X_c; H^NEW = H/H_0
% Note that aspect ratio alpha = X_c^2/H_0 = 100 in this case
load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
% X_inf/X_c = 10.^(0.3:0.1:4); so numb = 8 is for 10X_c; 18 for 100X_c, 
% 28 for 1000X_c and 38 for 10000X_c
numb = 8;
l1=semilogx(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf,'-','LineWidth',0.9,'color',col1); hold on
numb = 18;
l2=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf,'-','LineWidth',0.9,'color',col2); hold on
numb = 28;
l3=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf,'-','LineWidth',0.9,'color',col3); hold on
numb = 38;
l4=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf,'-','LineWidth',0.9,'color',col4); hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [4e-2 1e3]; % up to 8X_c
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$X=x/x_c$','interpreter','latex','fontsize',12);
ylabel('$H=h/h_0$','interpreter','latex','fontsize',12);
lgd = legend([l1,l2,l3,l4],'$X_{\infty} = 10 $','$X_{\infty} = 10^2$','$X_{\infty} = 10^3$','$X_{\infty} = 10^4$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);
%% Profiles for X_c = 100, X_inf = 10，and various H_0
%Note that X^NEW = X/X_c; H^NEW = H/H_0

% X_inf/X_c = 10.^(0.3:0.1:4); so numb = 8 is for 10X_c; 18 for 100X_c, 
% 28 for 1000X_c and 38 for 10000X_c

numb =8;
load('Static_h0_1000_a series of X_inf_LargeSlope_Rotation.mat')
% Note that aspect ratio alpha = X_c^2/H_0 = 10 in this case
l1=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf/(Xc^2/H_inf),'-','LineWidth',0.9,'color',col1); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
% Note that aspect ratio alpha = X_c^2/H_0 = 100 in this case
l2=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf/(Xc^2/H_inf),'-','LineWidth',0.9,'color',col2); hold on

load('Static_h0_10_a series of X_inf_LargeSlope_Rotation.mat')
% Note that aspect ratio alpha = X_c^2/H_0 = 1000 in this case
l3=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf/(Xc^2/H_inf),'-','LineWidth',0.9,'color',col3); hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [0 10]; % up to 2X_c
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$X=x/x_c$','interpreter','latex','fontsize',12);
ylabel('$H/\alpha=h/x_c$','interpreter','latex','fontsize',12);
lgd = legend([l1 l2 l3],'$\alpha = 10$','$\alpha = 10^2$','$\alpha = 10^3$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);
%% Profiles for X_c = 100, X_inf = 100，and various V_gamma
%Note that X^NEW = X/X_c; H^NEW = H/H_0
% Note that aspect ratio alpha = X_c^2/H_0 = 100 in this case


% X_inf/X_c = 10.^(0.3:0.1:4); so numb = 8 is for 10X_c; 18 for 100X_c, 
% 28 for 1000X_c and 38 for 10000X_c

numb =8;
load('Vg_1e-4_LargeSlope_Rotation.mat')
l1=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf/(Xc^2/H_inf),'-','LineWidth',0.9,'color',col1); hold on

load('Vg_1e-2_LargeSlope_Rotation.mat')
l2=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf/(Xc^2/H_inf),'-','LineWidth',0.9,'color',col2); hold on

load('Vg_1e0_LargeSlope_Rotation.mat')
l3=plot(x_rec(numb,:)/Xc,y_rec(numb,:)/H_inf/(Xc^2/H_inf),'-','LineWidth',0.9,'color',col3); hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [0 3]; % up to 2X_c
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$X=x/x_c$','interpreter','latex','fontsize',12);
ylabel('$H/\alpha =h/x_c$','interpreter','latex','fontsize',12);
lgd = legend([l1 l2 l3],'$\mathcal{V}_\gamma = 10^{-4}$','$\mathcal{V}_\gamma = 10^{-2}$','$\mathcal{V}_\gamma = 10^{0}$','interpreter','latex');
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);