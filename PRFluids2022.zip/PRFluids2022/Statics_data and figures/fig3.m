% In draft, H_inf is H_0
% nXc = 10.^(0.3:0.1:4); % Define X_inf = nXc*Xc
c        = parula(3); % Set color vector
col1=c(1,:);col2=c(2,:);col3=c(3,:);
%% H @ Xc
% Note that X_c = xc/l_vdw = 100 in all dataset 
tt=tiledlayout(2,1)
tt.TileSpacing = 'none';
ax = nexttile;

load('Static_h0_1000_a series of X_inf.mat')
% linearized eqns, aspect ratio alpha = X_c^2/H_0 = 10 in this case
plot(nXc,hXc/(H_inf)^0.5/Xc,'--','LineWidth',0.9,'color',col1); hold on
load('Static_h0_100_a series of X_inf.mat')
% linearized eqns, aspect ratio alpha = X_c^2/H_0 = 100 in this case
plot(nXc,hXc/(H_inf)^0.5/Xc,'--','LineWidth',0.9,'color',col2); hold on
load('Static_h0_10_a series of X_inf.mat')
% linearized eqns, aspect ratio alpha = X_c^2/H_0 = 1000 in this case
plot(nXc,hXc/(H_inf)^0.5/Xc,'--','LineWidth',0.9,'color',col3); hold on

load('Static_h0_1000_a series of X_inf_LargeSlope_Rotation.mat')
% fully nonlinearized eqns, aspect ratio alpha = X_c^2/H_0 = 10 
plot(nXc,hXc/(H_inf)^0.5/Xc,'-','LineWidth',0.9,'color',col1); hold on
load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
% fully nonlinearized eqns, aspect ratio alpha = X_c^2/H_0 = 100
plot(nXc,hXc/(H_inf)^0.5/Xc,'-','LineWidth',0.9,'color',col2); hold on
load('Static_h0_10_a series of X_inf_LargeSlope_Rotation.mat')
% fully nonlinearized eqns, aspect ratio alpha = X_c^2/H_0 = 1000 
plot(nXc,hXc/(H_inf)^0.5/Xc,'-','LineWidth',0.9,'color',col3); hold on

%%%small-skirt limit
X_ana = 10.^(0:0.01:2); H_ana = sqrt(3/8)*(X_ana).^0.5;
plot(X_ana,H_ana,'k-','LineWidth',1); hold on
%%%large-skirt limit
comb  = 0.50;
X_ana = 10.^(3:0.01:4); H_ana = 10^0.5*comb*(X_ana).^0;
plot(X_ana,H_ana,'k:','LineWidth',1); hold on
X_ana = 10.^(3:0.01:4); H_ana = 100^0.5*comb*(X_ana).^0;
plot(X_ana,H_ana,'k:','LineWidth',1); hold on
X_ana = 10.^(3:0.01:4); H_ana = 1000^0.5*comb*(X_ana).^0;
plot(X_ana,H_ana,'k:','LineWidth',1); hold on


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [1e1 1e4]; % down to 2X_c
ax.YLim   = [0.8 25]; 

set(gca,'XScale','log')
set(gca,'YScale','log')

set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
% xlabel('$X_\infty/X_c$','interpreter','latex','fontsize',12);
ylabel('$H_c/\alpha^{1/2}$','interpreter','latex','fontsize',12);
set(ax,'XTicklabels',[]);
% lgd = legend('$H_0 = 10$','$H_0 = 10^2$','$H_0 = 10^3$','interpreter','latex');
% set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);
% tex=text(10,10,'$\mathrm{Small ~skirt}$','FontSize',8,'interpreter','latex');
% set(tex,'Rotation',20)
% tex=text(10,10,'$\mathrm{Large ~skirt}$','FontSize',8,'interpreter','latex');


%% P at infinity
ax = nexttile;

load('Static_h0_1000_a series of X_inf.mat')
plot(nXc,(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)),'--','LineWidth',0.9,'Color',col1); hold on

load('Static_h0_100_a series of X_inf.mat')
plot(nXc,(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)),'--','LineWidth',0.9,'Color',col2); hold on

load('Static_h0_10_a series of X_inf.mat')
plot(nXc(1:end),(-y_rec(1:end,end).^(-3)+Bo*y_rec(1:end,end)),'--','LineWidth',0.9,'Color',col3); hold on

% load('Static_h0_1000_a series of X_inf_refined.mat')
% plot(nXc,(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)),'--','LineWidth',0.9,'Color',col3); hold on


load('Static_h0_1000_a series of X_inf_LargeSlope_Rotation.mat')
plot(nXc,(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)),'-','LineWidth',0.9,'Color',col1); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
plot(nXc,(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)),'-','LineWidth',0.9,'Color',col2); hold on

load('Static_h0_10_a series of X_inf_LargeSlope_Rotation.mat')
plot(nXc(1:end),(-y_rec(1:end,end).^(-3)+Bo*y_rec(1:end,end)),'-','LineWidth',0.9,'Color',col3); hold on

% %%%small-skirt limit
% X_ana = 10.^(0:0.01:2); H_ana = -(24*10/Xc^2)^(-1/2)*(X_ana).^(-0.5);
% plot(X_ana,H_ana,'k--','LineWidth',0.8,'Color',col1); hold on
% X_ana = 10.^(0:0.01:2); H_ana = -(24*100/Xc^2)^(-1/2)*(X_ana).^(-0.5);
% plot(X_ana,H_ana,'k--','LineWidth',0.8,'Color',col2); hold on
% X_ana = 10.^(0:0.01:2); H_ana = -(24*1000/Xc^2)^(-1/2)*(X_ana).^(-0.5);
% plot(X_ana,H_ana,'k--','LineWidth',0.8,'Color',col3); hold on
% %%%large-skirt limit
% X_ana = 10.^(3:0.01:4); H_ana = 10*Bo+0*(X_ana).^0;
% plot(X_ana,H_ana,'k:','LineWidth',0.8); hold on
% X_ana = 10.^(3:0.01:4); H_ana = 100*Bo+0*(X_ana).^0;
% plot(X_ana,H_ana,'k:','LineWidth',0.8); hold on
% X_ana = 10.^(3:0.01:4); H_ana = 1000*Bo+0*(X_ana).^0;
% plot(X_ana,H_ana,'k:','LineWidth',0.8); hold on


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [10 1e4]; % down to 2X_c
ax.YLim   = [-2 0.4]; % down to 2X_c

set(gca,'XScale','log')
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$X_\infty=x_\infty/x_c$','interpreter','latex','fontsize',12);
ylabel('$ P_\infty/\alpha$','interpreter','latex','fontsize',12);
% set(ax,'XTicklabels',[]);
%% Inset in the pressure plot

load('Static_h0_1000_a series of X_inf_LargeSlope_Rotation.mat')
A = Xc^2/H_inf;
loglog(-(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)).^(-1),hXc/Xc^2,'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col1); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
A = Xc^2/H_inf;
plot(-(-y_rec(:,end).^(-3)+Bo*y_rec(:,end)).^(-1),hXc/Xc^2,'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col2); hold on

load('Static_h0_10_a series of X_inf_LargeSlope_Rotation.mat')
A = Xc^2/H_inf;
plot(-(-y_rec(1:end,end).^(-3)+Bo*y_rec(1:end,end)).^(-1),hXc(1:end)/Xc^2,'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col3); hold on


X_ana = 10.^(-1:0.01:0.2); H_ana = (1/8)*(X_ana);
plot(X_ana,H_ana,'k-','LineWidth',1); hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
% ax.XLim   = [1e-1 200]; % down to 2X_c
% ax.YLim   = [2e2 8000]; % down to 2X_c

% set(gca,'XScale','log')
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$\alpha/(-P_\infty)$','interpreter','latex','fontsize',8);
ylabel('$H_c/\alpha$','interpreter','latex','fontsize',8);
% set(ax,'XTicklabels',[]);
%% to draw legend
ax.XLim   = [1e6 1e7]; % down to 2X_c
ax.YLim   = [1e6 1e7]; % down to 2X_c
lgd = legend('$\mathcal{V}_\gamma = 10^0,\mathcal{A} = 10^3$','$\mathcal{V}_\gamma = 10^{-4},\mathcal{A} = 10^2$','$\mathcal{V}_\gamma = 10^{-8}, \mathcal{A} = 10$','interpreter','latex');
set(lgd,'fontsize',10); set(lgd, 'Box', 'off'); axis off
%% Skirt volume
tt=tiledlayout(2,1)
tt.TileSpacing = 'none';
ax = nexttile;
load('Static_h0_1000_a series of X_inf.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - 1.01*y_rec(i,end); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:end));
end
loglog(nXc,volume/Xc/H_inf,'--','LineWidth',0.9,'Color',col1); hold on

load('Static_h0_100_a series of X_inf.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - 1.01*y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
loglog(nXc,volume/Xc/H_inf,'--','LineWidth',0.9,'Color',col2); hold on

load('Static_h0_10_a series of X_inf.mat')
lengx  =  length(x_rec(1,:)); dx(1:lengx-1) = x_rec(1,2:lengx)-x_rec(1,1:lengx-1);
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - 1.01*y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
loglog(nXc,volume/Xc/H_inf,'--','LineWidth',0.9,'Color',col3); hold on


load('Static_h0_1000_a series of X_inf_LargeSlope_Rotation.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - 1.01*y_rec(i,end); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:end));
end
loglog(nXc,volume/Xc/H_inf,'-','LineWidth',0.9,'Color',col1); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - 1.01*y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
loglog(nXc,volume/Xc/H_inf,'-','LineWidth',0.9,'Color',col2); hold on

load('Static_h0_10_a series of X_inf_LargeSlope_Rotation.mat')
lengx  =  length(x_rec(1,:)); dx(1:lengx-1) = x_rec(1,2:lengx)-x_rec(1,1:lengx-1);
for i = 1:38
lengx      =  length(x_rec(i,:)); dx(1:lengx-1) = x_rec(i,2:lengx)-x_rec(i,1:lengx-1); % the x mesh has been the same for all cases
profile    = y_rec(i,:) - 1.01*y_rec(i,lengx); 
profile(profile<0) = 0; % make negative values zero
volume(i)  = sum(dx.*profile(2:lengx));
end
loglog(nXc,volume/Xc/H_inf,'-','LineWidth',0.9,'Color',col3); hold on

%%%small-skirt limit
X_ana = 10.^(0:0.01:2.5); v_ana = (X_ana);
plot(X_ana,v_ana,'k-','LineWidth',1); hold on
%%%large-skirt limit
comb  = 0.50/0.1;
X_ana = 10.^(3:0.01:4); v_ana = 10*comb*(X_ana).^0;
plot(X_ana,v_ana,'k:','LineWidth',1); hold on
X_ana = 10.^(3:0.01:4); v_ana = 100*comb*(X_ana).^0;
plot(X_ana,v_ana,'k:','LineWidth',1); hold on
X_ana = 10.^(3:0.01:4); v_ana = 1000*comb*(X_ana).^0;
plot(X_ana,v_ana,'k:','LineWidth',1); hold on


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [1e1 10^4];
ax.YLim   = [5e0 0.99e4];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
% set(gca,'XScale','log')
set(ax,'XTicklabels',[]);

% xlabel('$X_\infty/X_c$','interpreter','latex','fontsize',12);
ylabel('$V_\mathrm{skirt}$','interpreter','latex','fontsize',12);  

% lgd = legend('$H_0 = 10$','$H_0 = 10^2$','$H_0 = 10^3$','interpreter','latex');
% set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);
% tex=text(10,10,'$\mathrm{Small ~skirt}$','FontSize',8,'interpreter','latex');
% set(tex,'Rotation',20)
% tex=text(10,10,'$\mathrm{Large ~skirt}$','FontSize',8,'interpreter','latex');


%% H at infinity
ax = nexttile;

load('Static_h0_1000_a series of X_inf.mat')
loglog(nXc,y_rec(:,end)/H_inf,'--','LineWidth',0.9,'Color',col1); hold on

load('Static_h0_100_a series of X_inf.mat')
plot(nXc,y_rec(:,end)/H_inf,'--','LineWidth',0.9,'Color',col2); hold on

load('Static_h0_10_a series of X_inf.mat')
plot(nXc(1:end),y_rec(1:end,end)/H_inf,'--','LineWidth',0.9,'Color',col3); hold on

% load('Static_h0_10_a series of X_inf_refined.mat')
% plot(nXc,y_rec(:,end)/H_inf,'--','LineWidth',0.9,'Color',col3); hold on


load('Static_h0_1000_a series of X_inf_LargeSlope_Rotation.mat')
loglog(nXc,y_rec(:,end)/H_inf,'-','LineWidth',0.9,'Color',col1); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
plot(nXc,y_rec(:,end)/H_inf,'-','LineWidth',0.9,'Color',col2); hold on

load('Static_h0_10_a series of X_inf_LargeSlope_Rotation.mat')
plot(nXc(1:end),y_rec(1:end,end)/H_inf,'-','LineWidth',0.9,'Color',col3); hold on

%%%small-skirt limit
X_ana = 10.^(0:0.01:1.5); H_ana = (24/Xc^2/10^5)^(1/6)*(X_ana).^(0.5/3);
plot(X_ana,H_ana,'k-','LineWidth',1); hold on
X_ana = 10.^(0:0.01:1.5); H_ana = (24/Xc^2/100^5)^(1/6)*(X_ana).^(0.5/3);
plot(X_ana,H_ana,'k-','LineWidth',1); hold on
X_ana = 10.^(0:0.01:1.5); H_ana = (24/Xc^2/1000^5)^(1/6)*(X_ana).^(0.5/3);
plot(X_ana,H_ana,'k-','LineWidth',1); hold on
%%%large-skirt limit
X_ana = 10.^(3:0.01:4); H_ana = 1*(X_ana).^0;
plot(X_ana,H_ana,'k:','LineWidth',1); hold on


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; 
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [10 1e4]; % down to 2X_c
ax.YLim   = [1e-3 2]; % down to 2X_c

set(gca,'XScale','log')
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
xlabel('$X_\infty=x_\infty/x_c$','interpreter','latex','fontsize',12);
ylabel('$H_\infty$','interpreter','latex','fontsize',12);
% set(ax,'XTicklabels',[]);