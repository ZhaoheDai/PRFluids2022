% In draft, H_inf is H_0
% nXc = 10.^(0.3:0.1:4); % Define X_inf = nXc*Xc
c        = parula(3); % Set color vector
col1=c(1,:);col2=c(2,:);col3=c(3,:);col4=c(3,:);
% c        = parula(3); % Set color vector
% col1=c(1,:);col2=c(2,:);col3=c(3,:);
%% Angles
load('Static_h0_100_a series of X_inf.mat')
slope1   = (y_rec(:,1001)-y_rec(:,1000))./(x_rec(:,1001)-x_rec(:,1000));
slope2   = (y_rec(:,1002)-y_rec(:,1003))./(x_rec(:,1002)-x_rec(:,1003));
rotat    = (slope1+slope2)/2/Xc;
% plot(nXc,asin(abs(slope1/Xc))-pi/6,'b--','LineWidth',0.9,'color',col1); hold on
% plot(nXc,asin(abs(slope2/Xc))-pi/6,'g--','LineWidth',0.9,'color',col2); hold on
plot(nXc,(abs(slope1/Xc))-1/2,'b--','LineWidth',0.9,'color',col1); hold on
plot(nXc,(abs(slope2/Xc))-1/2,'g--','LineWidth',0.9,'color',col2); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
slope1   = (y_rec(:,1001)-y_rec(:,1000))./(x_rec(:,1001)-x_rec(:,1000));
slope2   = (y_rec(:,1002)-y_rec(:,1003))./(x_rec(:,1002)-x_rec(:,1003));
rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
% l1=plot(nXc,(atan(abs(slope1/Xc)))-pi/6,'b-','LineWidth',0.9,'color',col1); hold on
% l2=plot(nXc,(atan(abs(slope2/Xc)))-pi/6,'g-','LineWidth',0.9,'color',col2); hold on
l1=plot(nXc,sin(atan(abs(slope1/Xc)))-1/2,'b-','LineWidth',0.9,'color',col1); hold on
l2=plot(nXc,sin(atan(abs(slope2/Xc)))-1/2,'g-','LineWidth',0.9,'color',col2); hold on

axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [2 10^4];
% ax.YLim   = [-0.03 0.5];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
set(gca,'XScale','log')
lgd = legend([l1 l2],'$\theta^-$','$\theta^+$','interpreter','latex')
set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);

xlabel('$X_\infty=x_\infty/x_c$','interpreter','latex','fontsize',12);
% ylabel('$\mathrm{Arctan}(|H_X/\mathcal{A}|)-\pi/6$','interpreter','latex','fontsize',12);  
ylabel('$\theta^{\pm}-\pi/6$','interpreter','latex','fontsize',12);  


%% Rotation of the triangle
load('Static_h0_100_a series of X_inf.mat')
slope1   = (y_rec(:,1001)-y_rec(:,1000))./(x_rec(:,1001)-x_rec(:,1000));
slope2   = (y_rec(:,1002)-y_rec(:,1003))./(x_rec(:,1002)-x_rec(:,1003));
rotat    = (slope1+slope2)/2/Xc;
% rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
plot(nXc,asin(rotat),'--','LineWidth',0.9,'color',col1); hold on
% plot(nXc(2),rotat(2),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col1); hold on
% plot(nXc(20),rotat(20),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col1); hold on

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
slope1   = (y_rec(:,1001)-y_rec(:,1000))./(x_rec(:,1001)-x_rec(:,1000));
slope2   = (y_rec(:,1002)-y_rec(:,1003))./(x_rec(:,1002)-x_rec(:,1003));
% rotat    = (slope1+slope2)/2/Xc;
rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
plot(nXc,asin(rotat),'-','LineWidth',0.9,'color',col1); hold on
plot(nXc(2),asin(rotat(2)),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col1); hold on
plot(nXc(18),asin(rotat(18)),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col1); hold on

load('Static_h0_100_a series of X_inf_situation_b.mat')
slope1   = (y_rec(:,1001)-y_rec(:,1000))./(x_rec(:,1001)-x_rec(:,1000));
slope2   = (y_rec(:,1002)-y_rec(:,1003))./(x_rec(:,1002)-x_rec(:,1003));
rotat    = (slope1+slope2)/2/Xc;
% rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
plot(nXc,asin(rotat),'--','LineWidth',0.9,'color',col2); hold on
% plot(nXc(2),rotat(2),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col3); hold on
% plot(nXc(20),rotat(20),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col3); hold on

load('Static_h0_100_a series of X_inf_situation_b_LargeSlope_Rotation.mat')
slope1   = (y_rec(:,1001)-y_rec(:,1000))./(x_rec(:,1001)-x_rec(:,1000));
slope2   = (y_rec(:,1002)-y_rec(:,1003))./(x_rec(:,1002)-x_rec(:,1003));
% rotat    = (slope1+slope2)/2/Xc;
rotat    = -(1+slope1.^2/Xc^2).^(-0.5)+(1+slope2.^2/Xc^2).^(-0.5);
plot(nXc,asin(rotat),'-','LineWidth',0.9,'color',col2); hold on
plot(nXc(4),asin(rotat(4)),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col2); hold on
plot(nXc(20),asin(rotat(20)),'o','MarkerSize',3,'MarkerEdgeColor','k','MarkerFaceColor',col2); hold on


%%%large-skirt limit
X_ana = 10.^(2:0.01:4); t_ana = 0.465+0*X_ana;
plot(X_ana,asin(t_ana),'k:','LineWidth',0.8); hold on

tex=text(10,0.2,'Large-system limit','FontSize',8,'interpreter','latex');
tex=text(10,0.2,'{Push \& pull}','FontSize',8,'interpreter','latex','color',col1);
set(tex,'Rotation',22)
tex=text(10,0.2,'{Pull only}','FontSize',8,'interpreter','latex','color',col2);
tex=text(10,0.2,'$X_\infty=2.5$','FontSize',8,'interpreter','latex','color','k');
tex=text(10,0.2,'$X_\infty=100$','FontSize',8,'interpreter','latex','color','k');


axis on;
ax = gca;
ax.TickLabelInterpreter   =  'latex';
ax.MinorGridAlpha         =  0.1; %%Minor grid line transparency:A value of 1 means opaque and a value of 0 means completely transparent.
ax.GridAlpha              =  0.1;
ax.XMinorTick             =  'on';
ax.YMinorTick             =  'on';
ax.TickLength             =  [0.02 0.02];
ax.XLim   = [2 10^4];
ax.YLim   = [-0.6 0.6];

% ax.YLim   = [-0.03 0.5];
set(ax,'fontsize',10)
set(ax,'LineWidth',0.4)
set(gca,'XScale','log')

xlabel('$X_\infty=x_\infty/x_c$','interpreter','latex','fontsize',12);
ylabel('$\Delta\theta$','interpreter','latex','fontsize',12);  

% lgd = legend('$H_0 = 10$','$H_0 = 10^2$','$H_0 = 10^3$','interpreter','latex');
% set(lgd, 'Box', 'off'); set(lgd,'fontsize',10);
% tex=text(10,0.2,'$\mathrm{Small ~skirt}$','FontSize',8,'interpreter','latex');
% tex=text(10,0.2,'$\mathrm{Large ~skirt}$','FontSize',8,'interpreter','latex');
%% profiles
figure;
numb =2;

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
plot(x_rec(numb,:),y_rec(numb,:),'-','LineWidth',1,'color',col1); hold on
load('Static_h0_100_a series of X_inf_situation_b_LargeSlope_Rotation.mat')
plot(x_rec(numb+2,:),y_rec(numb+2,:),'-','LineWidth',1,'color',col2);
%%+2 because this file contains 40 point rather 38 - in other cases

load('Static_h0_100_a series of X_inf.mat')
plot(x_rec(numb,:),y_rec(numb,:),'--','LineWidth',1,'color',col1); hold on
load('Static_h0_100_a series of X_inf_situation_b.mat')
plot(x_rec(numb,:),y_rec(numb,:),'--','LineWidth',1,'color',col2);

axis on;
ax = gca;
ax.XLim   = [-1 500];
ax.YLim   = [-1 5000];
axis on;
axis off;

%%
numb =18;

load('Static_h0_100_a series of X_inf_LargeSlope_Rotation.mat')
plot(x_rec(numb,:),y_rec(numb,:),'-','LineWidth',1,'color',col1); hold on
load('Static_h0_100_a series of X_inf_situation_b_LargeSlope_Rotation.mat')
plot(x_rec(numb+2,:),y_rec(numb+2,:),'-','LineWidth',1,'color',col2);
%%+2 because this file contains 40 point rather 38 - in other cases

load('Static_h0_100_a series of X_inf.mat')
plot(x_rec(numb,:),y_rec(numb,:),'--','LineWidth',1,'color',col1); hold on
load('Static_h0_100_a series of X_inf_situation_b.mat')
plot(x_rec(numb,:),y_rec(numb,:),'--','LineWidth',1,'color',col2);

axis on;
ax = gca;
ax.XLim   = [-1 400];
ax.YLim   = [-1 10000];
axis on;
axis off;


